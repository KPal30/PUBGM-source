////全局配置BSPHP
////下面信息通过软件后台>软件>对应软件设置上获得
////全局服务器地址
//#import <Foundation/Foundation.h>
//
//
//#define  LD_API  @"0CNDJZhaOLgFASOXO/1RgjTmRSgUi9IIYxQbUq+7rT6FSzlyG8bX0tdPK71+FAwhc8/3Gr7x8bCQUUfFr53XJH6f3jCO9i8AFW+6jWJn3kClbuf5hMd+7g=="
////通信key
//#define LD_KEY @"t9ACbqR7LtnE4+bb698E39AqDJujyZrrYgfFgbpko70Bz9rvwnpxSQ=="
//
////通信密码
//#define LD_APIPASS @"Myc6sPs5yWj5uOVqc0N7c9kcqIMqp+wM"
////默认无修改
//#define LD_AAAA @"123456781234567812345678"
////远程菜单
////QQ飞飞车pqrGPtGQWD46tXNw0D/F5T0AhXHudnKfH0VQ5tMgsyU9MEjXAMKKCA==
////王者pqrGPtGQWD46tXNw0D/F5T0AhXHudnKfx8SpJ05NV2xi+eupx7CFnO1JTJeqmJOY
////#define LD_URL @"“
////签名in进认证
//#define LD_IN @"1ZwD4tYX1ZaYTVB9VTKtIQ=="
////签名to本地认证
//#define LD_TO @"1ZwD4tYX1ZbS6ch52ckRfw=="
//
//
//#define LD_VERSION @"99g/St5CRYY="
////BSphp加密方式请勿修改
//#define LD_TXT @"WCJLVNUkwREF+8eFIBOJabw1hYx8ddqf7d1NE3l79xWjf1r2gwJ1Hs47NcZqqnQbKWlX5MvtyYk="
////BSphp加密方式api请勿修改
//#define LD_SQTITLE @"3Ow8DS7D8wQEscrAVUpR4Q=="
//#define LD_LTURL @"pqrGPtGQWD44zQd4IQeFpz599DW+bUJE"
////
//
//@interface NetTool : NSObject
//
///**
// *  AFN异步发送post请求，返回原生数据
// *
// *  @param appendURL 追加URL
// *  @param param     参数字典
// *  @param success   成功Block
// *  @param failure   失败Block
// *
// *  @return NSURLSessionDataTask任务类型
// */
//+ (NSURLSessionDataTask *)__attribute__((optnone))Post_AppendURL:(NSString *)appendURL myparameters:(NSDictionary *)param mysuccess:(void (^)(id responseObject))success myfailure:(void (^)(NSError *error))failure;
//@end
