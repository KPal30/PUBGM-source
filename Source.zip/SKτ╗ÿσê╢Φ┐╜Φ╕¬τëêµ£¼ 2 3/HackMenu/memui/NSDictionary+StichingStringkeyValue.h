//
//  NSDictionary+StichingStringkeyValue.h
//  BSPHPOC
//
//  Created by MRW on 2016/12/28.
//  Copyright © 2016年 xiaozhou. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (StichingStringkeyValue)
+ (NSString *)__attribute__((optnone))stitchingStringFromDictionary:(NSDictionary *)dictionary;
@end
