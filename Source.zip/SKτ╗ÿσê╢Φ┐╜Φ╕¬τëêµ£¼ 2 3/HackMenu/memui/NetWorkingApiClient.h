// 十三哥 QQ350722326
//官网 https://iosgods.cn

#import "AFNetworking.h"

@interface NetWorkingApiClient : AFHTTPSessionManager
+ (NetWorkingApiClient *)sharedNetWorkingApiClient;
@end
