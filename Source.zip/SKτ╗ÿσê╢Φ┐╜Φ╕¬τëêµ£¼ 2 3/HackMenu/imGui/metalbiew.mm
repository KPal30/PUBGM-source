#import "lanjie.h"
#import "metalbiew.h"
#import <Metal/Metal.h>
#import <UIKit/UIKit.h>
#import <MetalKit/MetalKit.h>
#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import "dobby.h"
#import "vm_writeData.h"
#import "YMCJInfoModel.h"
#import "MBProgressHUD.h"
#import "JHCJInfoStringTools.h"
#import "HeeeNoScreenShotView.h"
#include "imgui.h"
#include "imgui_impl_metal.h"
#include <JRMemory/MemScan.h>
#include "YMCJDrawDataFactory.h"

#define UIColorFromRGBA(rgbValue, alphaValue) [UIColor colorWithRed:((float)((rgbValue & 0xFF0000) >> 16))/255.0 green:((float)((rgbValue & 0x00FF00) >> 8))/255.0 blue:((float)(rgbValue & 0x0000FF))/255.0 alpha:alphaValue]

#define iPhone8P ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)
#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
#define kTest   0



BOOL kaiqi1=NO;
BOOL kaiqi=NO;
//BOOL dongtai=NO;

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
@interface metalbiew () <MTKViewDelegate>
@property (nonatomic, strong) IBOutlet MTKView *mtkView;
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;

@property (nonatomic,  strong) UILabel *numberLabel;
@property (nonatomic,  strong) NSMutableArray *wuziViews;
@property (nonatomic,  strong) NSMutableDictionary *ftViewsInfo;
@property (nonatomic,  strong) NSMutableArray *usedModes;
@property (nonatomic,  strong) NSMutableArray *cacheModes;
@property (nonatomic,  strong) NSArray *wuziArray;
@property (nonatomic,  strong) CAShapeLayer *Line_Red;
@property (nonatomic,  strong) CAShapeLayer *Line_Green;
@property (nonatomic,  strong) NSMutableArray *infoViews;
@property (nonatomic, strong) NSArray *numberData;
@property (nonatomic,  strong) CAShapeLayer *renji;
@property (nonatomic,  strong) NSArray *rects;
@property (nonatomic,  strong) NSArray *aiData;
@property (nonatomic,  strong) NSArray *hpData;
@property (nonatomic,  strong) NSArray *disData;
@property (nonatomic,  strong) NSArray *nameData;
@property (nonatomic,  strong) NSArray *data1;
@property (nonatomic,  strong) NSArray *data2;
@property (nonatomic,  strong) NSArray *data3;
@property (nonatomic,  strong) NSArray *data4;
@property (nonatomic,  strong) NSArray *data5;
@property (nonatomic,  strong) NSArray *data6;
@property (nonatomic,  strong) NSArray *data7;
@property (nonatomic,  strong) NSArray *data8;
@property (nonatomic, copy) NSString *Name;
@property (nonatomic,  weak) NSTimer *timer;
@property (nonatomic) CGPoint aimPoint;
@property (nonatomic,  strong) NSArray *infoArray;
@end



static CATextLayer *m[100];
static CATextLayer *mm[100];
static CATextLayer *h[100];
static CATextLayer *c[100];
static CATextLayer *a[100];
#define Yellow 0xFFC125FF
#define Green 0x008000
#define Red 0xFF0000
#define R 0xff0000ff
#define baise 0xFFFFFFFF
#define lvse
#define Red 0xff0000ff
#define tan 0xFFDB9370
#define Green 0xff00FF00
#define Yellow 0xff00ffff
#define Blue 0xffff0000
#define Pink 0xffeb8cfe
#define White 0xffffffff
#define Orange 0xFF00FFFF
#define Black 0x99000000
#define gray 0xffD3D3D3
@implementation metalbiew
static bool show_wuhou = false;
static bool MenDeal = true;

//static int fanwei = 300000;
+(void)load{
    
    
    
    
    [[metalbiew alloc] Show];
    
    
}
- (void)Show
{
    
    self.timer.fireDate = [NSDate distantPast];
}

- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    
    _device = MTLCreateSystemDefaultDevice();
    
    _commandQueue = [_device newCommandQueue];
    
    if (!self.device) abort();
    
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    
    ImGui::StyleColorsDark();
    
    NSString *FontPath = @"/System/Library/Fonts/LanguageSupport/PingFang.ttc";
    io.Fonts->AddFontFromFileTTF(FontPath.UTF8String, 40.f,NULL,io.Fonts->GetGlyphRangesChineseSimplifiedCommon());
    
    ImGui_ImplMetal_Init(_device);
    
    return self;
}

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{
    
    self.view = [[MTKView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];

}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    
}

- (void)configWithData:infoArray:(NSArray *)infoArray aimPos:(CGPoint) aimPos
{
    
    NSArray *wuzi = [infoArray filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(                lnfCJInfoModel *model, NSDictionary<NSString *,id> * _Nullable bindings) {
        if (model.flag > 1) {
            return YES;
        }
        return NO;
    }]];
    _wuziArray = wuzi;
    
    // 其他数据
    
    // 物资
    _infoArray = infoArray;
    if (wuzi.count > 0) {
        NSMutableArray *marr = [NSMutableArray arrayWithArray:infoArray];
        [marr removeObjectsInArray:wuzi];
        _infoArray = marr;
    }
    if (_infoArray.count == 0) {
        [_infoViews enumerateObjectsUsingBlock:^(UIView *obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.hidden = YES;
        }];
    }
    
    // 物资
    if (_wuziArray.count == 0) {
        
        
        [_wuziViews enumerateObjectsUsingBlock:^(UIImageView *obj, NSUInteger idx, BOOL * _Nonnull stop) {
            obj.hidden = YES;
        }];
    }
    _aimPoint = aimPos;
    _numberLabel.text = @(_infoArray.count).stringValue;
    //
    
}



#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *anyTouch = event.allTouches.anyObject;
    CGPoint touchLocation = [anyTouch locationInView:self.view];
    ImGuiIO &io = ImGui::GetIO();
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);
    
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in event.allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }
    io.MouseDown[0] = hasActiveTouch;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self updateIOWithTouchEvent:event];
}
#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
    
    [self doThe1Jo1b];
    
    
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;
    
    
    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1 / float(view.preferredFramesPerSecond ?: 65);
    
    if (iPhone8P){
        io.DisplayFramebufferScale = ImVec2(2.60, 2.60);
    }else{
        io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    }
    
    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    //绘制风格
    static bool show_Cheto = false;
    static bool show_niubi = false;
    static bool show_lien = false;
    static bool show_guge = false;
    static bool show_98 = false;
    //绘制设置
    static bool show_lien = false;
    static bool show_name = false;
    static bool show_xue = false;
    static bool show_dui = false;
    static bool show_guge = false;
    static bool show_juli = false;
    static bool show_number = false;
    //追踪设置
    static bool show_round = false; peraim = show_round;
    static bool dongtaizz = false;
    static int circle_size = 200; aimRadius = circle_size;
    static int shun = 0;
    static int fw = 0;
    shunji = shun;
    fwdaxiao = fw;
    //内存功能
    static bool show_JZ = false;
    static bool show_js = false;
    static bool show_gb = false;
    //菜单颜色
    static bool bai = true;//面板颜色

    if (MenDeal == true) {
        [self.view setUserInteractionEnabled:YES];
    } else if (MenDeal == false) {
        [self.view setUserInteractionEnabled:NO];
    }
    
    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (renderPassDescriptor != nil)
    {
        id <MTLRenderCommandEncoder> renderEncoder = [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
        [renderEncoder pushDebugGroup:@""];
        
        ImGui_ImplMetal_NewFrame(renderPassDescriptor);
        ImGui::NewFrame();
        
        ImFont* font = ImGui::GetFont();
        font->Scale = 16.f / font->FontSize;
        
        CGFloat x = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.width) - 360) / 2;
        CGFloat y = (([UIApplication sharedApplication].windows[0].rootViewController.view.frame.size.height) - 360) /2;
        
        ImGui::SetNextWindowPos(ImVec2(x, y), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(360, 320), ImGuiCond_FirstUseEver);
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                vm_writeData(0X1023F2CC4, 0xC0035FD6);
                vm_writeData(0x101D00FB8, 0XC0035FD6);
            });
        });
        if (MenDeal == true)
        {
            ImGui::Begin("PUBGM HACK", &MenDeal);
            
            ImGui::Text("Copright By YuWan");
            
            ImGui::Separator();//分割线
            if (ImGui::CollapsingHeader("绘制风格"))
            {
                if (ImGui::BeginTable("split", 3))
                {
                    ImGui::TableNextColumn(); ImGui::Checkbox("Cheto风格", &show_Cheto);
                    ImGui::TableNextColumn(); ImGui::Checkbox("特殊风格", &show_niubi);
                    ImGui::TableNextColumn(); ImGui::Checkbox("钢铁侠风格", &show_SSS);
                    ImGui::TableNextColumn();  ImGui::Checkbox("98S风格", &show_98);
                    
                    ImGui::EndTable();
                }
            }
            if (ImGui::CollapsingHeader("绘制功能"))
            {
                if (ImGui::BeginTable("split", 3))
                {
                    ImGui::TableNextColumn(); ImGui::Checkbox("射线", &show_lien);
                    ImGui::TableNextColumn(); ImGui::Checkbox("名字", &show_name);
                    ImGui::TableNextColumn(); ImGui::Checkbox("血量", &show_xue);
                    ImGui::TableNextColumn();  ImGui::Checkbox("队标", &show_dui);

ImGui::TableNextColumn(); ImGui::Checkbox("骨头", &show_guge);
                    ImGui::TableNextColumn(); ImGui::Checkbox("距离", &show_juli);
                    ImGui::TableNextColumn(); ImGui::Checkbox("人数", &show_number);
                    
                    ImGui::EndTable();
                }
            }
            if (ImGui::CollapsingHeader("追踪设置"))
            {
                if (ImGui::BeginTable("split", 3))
                {
                    ImGui::TableNextColumn(); ImGui::Checkbox("追踪", &show_round);
                    ImGui::TableNextColumn(); ImGui::Checkbox("动态追", &show_dongtaizz);

ImGui::Separator();
ImGui::SliderInt("追踪圈大小", &circle_size, 0, 500);
                   
ImGui::Separator();
ImGui::SliderInt("瞬击速度", &shun, 0, 2800000);

ImGui::Separator();
ImGui::SliderInt("范围大小", &fw, 0, 1500000);
                    
                    ImGui::EndTable();
                }
            }
            if (ImGui::CollapsingHeader("内存功能"))
            {
                if (ImGui::BeginTable("split", 3))
                {
                                        ImGui::TableNextColumn();  ImGui::Checkbox("出生防封", &show_JZ);
                    ImGui::TableNextColumn();  ImGui::Checkbox("开启加速",&show_js);
                    ImGui::TableNextColumn();  ImGui::Checkbox("关闭加速",&show_gb);
                    
                    ImGui::EndTable();
                }
            }
            if (ImGui::CollapsingHeader("菜单美化"))//Menu Settings
            {
                
                if (ImGui::BeginTable("split", 3))
                {
                    
                    ImGui::TableNextColumn(); if (ImGui::RadioButton("白色",bai)) {ImGui::StyleColorsLight();}
                    ImGui::TableNextColumn(); if (ImGui::RadioButton("黑色",bai)) {ImGui::StyleColorsClassic();}
                    ImGui::EndTable();
                }
                
                
                
                
                
            }
            ImGui::End();
        }
#pragma mark - 出生岛防
        if (show_JZ) {
            static dispatch_once_t onceToken;
            dispatch_once(&onceToken, ^{
                                vm_writeData(0x1013ED9A8, 0xC0035FD6);
                               vm_writeData(0X1016257F8, 0XC0035FD6);
                               vm_writeData(0X1027F8F84, 0XC0035FD6);

vm_writeData(0x10306A4E8, 0xC0035FD6);
                               vm_writeData(0X1030F63B4, 0XC0035FD6);
                               vm_writeData(0X1032E2A30, 0XC0035FD6);

vm_writeData(0x10234A55C, 0xC0035FD6);
                               vm_writeData(0X1021FA081, 0XC0035FD6);

            });
        }
#pragma mark - 开启跳伞加速
    if (show_js) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = (AddrRange){0x100000000,0x160000000};
            uint64_t search = 4453159312402940160;
            engine.JRScanMemory(range, &search, JR_Search_Type_ULong);
            vector<void*>results = engine.getAllResults();
            uint64_t modify = 9223372036854775807;
            for(int i = 0;i<results.size();i++){
                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
                //[WHToast showMessage:@"加速开启成功" duration:1 finishHandler:^{}];
            }});
        
    }
#pragma mark - 关闭跳伞加速
    if (show_gb) {
        static dispatch_once_t onceToken;
        dispatch_once(&onceToken, ^{
            
            JRMemoryEngine engine = JRMemoryEngine(mach_task_self());
            AddrRange range = (AddrRange){0x100000000,0x160000000};
            uint64_t search = 9223372036854775807;
            engine.JRScanMemory(range, &search, JR_Search_Type_ULong);
            vector<void*>results = engine.getAllResults();
            uint64_t modify = 4453159312402940160;
            for(int i = 0;i<results.size();i++){
                engine.JRWriteMemory((unsigned long long)(results[i]),&modify,JR_Search_Type_UInt);
                //[WHToast showMessage:@"加速关闭成功" duration:1 finishHandler:^{}];
            }});
    }
    
        ImDrawList* draw_list = ImGui::GetForegroundDrawList();
        for (NSInteger i = 0; i < _infoArray.count; i++) {
            lnfCJInfoModel *model = _infoArray[i];
            //
            float x = model.bon.Head.X;
            float y = model.bon.Head.Y;
           
            
          if(show_round && aimRadius !=0){
              peraim = true;
              draw_list->AddCircle(ImVec2(kWidth/2, kHeight/2), aimRadius, model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ?Green : Red,0.5);
              //aimRadius+
          if (fabs(kWidth/2 - self.aimPoint.x) > 1 ||
              fabs(kHeight/2 - self.aimPoint.y) > 1) {
              draw_list->AddLine(ImVec2(kWidth/2, kHeight/2), ImVec2(self.aimPoint.x, self.aimPoint.y),Green,0.2);
              
              //draw_list->AddCircle(ImVec2(self.aimPoint.x, self.aimPoint.y), 2, Yellow);
              
              }
          }else{
              peraim = false;
          }
        /*    if(huayuan){
            
                NSLog(@"**** daxiao %d",daxiao);
                       
           
               draw_list->AddCircle(ImVec2(kWidth/2, kHeight/2), circle_size, 0x806666FF);
        //   NSLog(@"**** daxiao %d",daxiao);
                //draw_list->AddLine(ImVec2(kWidth/2, kHeight/2), ImVec2(self.aimPoint.x,self.aimPoint.y) , Green,0.4);
                
                
            }*/
               if(show_lien){
                  if (model.isAI== 1) {
                      draw_list->AddLine(ImVec2(kWidth*0.5, linex), ImVec2(x,y-liney), White,0.4);
                  }else{//真人变色射线
                  if (model.distance<= 100) {
                      draw_list->AddLine(ImVec2(kWidth*0.5, linex), ImVec2(x,y-liney), Red,0.4);
                  }
                  if (model.distance<= 200&& model.distance >100) {
                      draw_list->AddLine(ImVec2(kWidth*0.5, linex), ImVec2(x,y-liney), Orange,0.4);
                  }
                  if (model.distance>200) {
                      draw_list->AddLine(ImVec2(kWidth*0.5, linex), ImVec2(x,y-liney), Yellow,0.4);
                  }
                  }
                   
                   
              // }
                
            }
        //动态圈
             if(dongtaizz){
                    //       if(x>=kWidth/2-dongtaibanjin && x<=kWidth/2+dongtaibanjin && y>=kHeight/2-dongtaibanjin && y<=kHeight/2+dongtaibanjin){
                                
                            draw_list->AddCircle(ImVec2(kWidth/2, kHeight/2), dongtaibanjin,Yellow,0.2);
                                                               }
                       
               //   }
            
            if (show_SSS){
                   if (xue) {
                                       
                       if(model.isAI){
                                                                             draw_list->AddLine(ImVec2(x-29.5, y-33), ImVec2(x-29+model.hp*0.65, y-33), gray,5.5);
                                                                         }else{
                                                                             draw_list->AddLine(ImVec2(x-29.5, y-33), ImVec2(x-29+model.hp*0.65, y-33), Green,5.5);
                                                                         }
                       
                              }
                if (name){
                    char* il = (char*) [[NSString stringWithFormat:@"%@",model.name] cStringUsingEncoding:NSUTF8StringEncoding];
                    draw_list->AddText(ImGui::GetFont(), 15, ImVec2(x-9, y-32),White, il);
                
                
            
            }
                if (show_juli) {
                   //距离
               
                    char* mi = (char*) [[NSString stringWithFormat:@"%d队|%dM",model.number,(int) model.distance] cStringUsingEncoding:NSUTF8StringEncoding];
                    draw_list->AddText(ImGui::GetFont(), 15, ImVec2(x-9, y-50),White, mi);
                    
                       
                }
            
                
                
                
                
                }
                        
                               
            
           
           
                           
            ///SSS风格
            if(Speak){
                Speak = true;
            }else{
                Speak = false;
            }
            
               //大牛风格
           if(show_niubi){
               if (xue) {
                   draw_list->AddRectFilled(ImVec2(model.bon.Head.X-26, model.bon.Head.Y-11), ImVec2(model.bon.Head.X-26+model.hp*0.5, model.bon.Head.Y-8), Red);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-16, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-6, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+6, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+16, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+25, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRectFilled(ImVec2(model.bon.Head.X-26, model.bon.Head.Y-11), ImVec2(model.bon.Head.X+25, model.bon.Head.Y-8), 0x20ffffff);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-16, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-6, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+6, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+16, model.bon.Head.Y-8), 0xff000000);
               draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+25, model.bon.Head.Y-8), 0xff000000);
           }
                if (name) {
                              if(model.isAI){
                                                       char* il = (char*) [[NSString stringWithFormat:@"%@",model.name] cStringUsingEncoding:NSUTF8StringEncoding];
                                                       draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-10, y+41),White, il);
                                                   }else{
                                                   char* il = (char*) [[NSString stringWithFormat:@"%@",model.name] cStringUsingEncoding:NSUTF8StringEncoding];
                                                       draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-10, y+41), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red, il);
                                                   }
                          }
                                                   //编号
                                                  if (dui) {
                                                      if(model.isAI){
                                                       char* ii = (char*) [[NSString stringWithFormat:@"%d",(int) model.number] cStringUsingEncoding:NSUTF8StringEncoding];
                                                       draw_list->AddText(ImGui::GetFont(), 18, ImVec2(x-7, y-55), White, ii);
                                                   }else{
                                                   char* ii = (char*) [[NSString stringWithFormat:@"%d",(int) model.number] cStringUsingEncoding:NSUTF8StringEncoding];
                                                   draw_list->AddText(ImGui::GetFont(), 18, ImVec2(x-7, y-55), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red, ii);
                                                   }
                                                  }
                                                  if (show_juli) {
                                                      //距离
                                                   if(model.isAI){
                                                   char* mi = (char*) [[NSString stringWithFormat:@"%d米",(int) model.distance] cStringUsingEncoding:NSUTF8StringEncoding];
                                                       draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-9, y+32),White, mi);
                                                   }else{
                                                    char* mi = (char*) [[NSString stringWithFormat:@"%d米",(int) model.distance] cStringUsingEncoding:NSUTF8StringEncoding];
                                                       draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-9, y+32), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red, mi);
                                                   }
                                               }
           }
        //Cheto风格
             if(show_98){
                          if (xue) {
                              draw_list->AddRectFilled(ImVec2(model.bon.Head.X-26, model.bon.Head.Y-11), ImVec2(model.bon.Head.X-26+model.hp*0.5, model.bon.Head.Y-8), Green);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-16, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-6, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+6, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+16, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+25, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRectFilled(ImVec2(model.bon.Head.X-26, model.bon.Head.Y-11), ImVec2(model.bon.Head.X+25, model.bon.Head.Y-8), 0x20ffffff);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-16, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X-6, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+6, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+16, model.bon.Head.Y-8), 0xff000000);
                          draw_list->AddRect(ImVec2(model.bon.Head.X-27, model.bon.Head.Y-12), ImVec2(model.bon.Head.X+25, model.bon.Head.Y-8), 0xff000000);
                      }
                          if (name){
                                              char* il = (char*) [[NSString stringWithFormat:@"%d %@",model.number,model.name] cStringUsingEncoding:NSUTF8StringEncoding];
                                              draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-9, y-9),Yellow, il);
                                          
                                          
                                      
                                      }
                                          if (show_juli) {
                                             //距离
                                         
                                          char* mi = (char*) [[NSString stringWithFormat:@"%d",(int) model.distance] cStringUsingEncoding:NSUTF8StringEncoding];
                                              draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-0, y-34.5),White, mi);
                                              
                                          }
                                          }
                   //Cheto风格
            
 if(show_Cheto){
     
     if (xue) {
       //  draw_list->AddRectFilled(ImVec2(x-35, y-38), ImVec2(x-30, y-28),gray);
                     
                 
                //血条框 掩体变色
                                     if(model.isAI){
                                         draw_list->AddRect(ImVec2(x-30, y-38), ImVec2(x+35, y-28),White,0.5);
                                     }else{
                                         draw_list->AddRect(ImVec2(x-30, y-38), ImVec2(x+35, y-28),model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red,0.5);
                                     }
                                     //血条 掩体变色
                                     if(model.isAI){
                                         draw_list->AddLine(ImVec2(x-29.5, y-33), ImVec2(x-29+model.hp*0.65, y-34), White,7.8);
                                     }else{
                                         draw_list->AddLine(ImVec2(x-29.5, y-33), ImVec2(x-29+model.hp*0.65, y-34), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red,7.8);
                                     }
     }
                                     //名字
            if (name) {
                if(model.isAI){
                                         char* il = (char*) [[NSString stringWithFormat:@"%@",model.name] cStringUsingEncoding:NSUTF8StringEncoding];
                                         draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-10, y+41),White, il);
                                     }else{
                                     char* il = (char*) [[NSString stringWithFormat:@"%@",model.name] cStringUsingEncoding:NSUTF8StringEncoding];
                                         draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-10, y+41), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red, il);
                                     }
            }
                                     //编号
                                    if (dui) {
                                        if(model.isAI){
                                         char* ii = (char*) [[NSString stringWithFormat:@"%d",(int) model.number] cStringUsingEncoding:NSUTF8StringEncoding];
                                         draw_list->AddText(ImGui::GetFont(), 18, ImVec2(x-7, y-55), White, ii);
                                     }else{
                                     char* ii = (char*) [[NSString stringWithFormat:@"%d",(int) model.number] cStringUsingEncoding:NSUTF8StringEncoding];
                                     draw_list->AddText(ImGui::GetFont(), 18, ImVec2(x-7, y-55), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red, ii);
                                     }
                                    }
                                    if (show_juli) {
                                        //距离
                                     if(model.isAI){
                                     char* mi = (char*) [[NSString stringWithFormat:@"%d米",(int) model.distance] cStringUsingEncoding:NSUTF8StringEncoding];
                                         draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-9, y+32),White, mi);
                                     }else{
                                      char* mi = (char*) [[NSString stringWithFormat:@"%d米",(int) model.distance] cStringUsingEncoding:NSUTF8StringEncoding];
                                         draw_list->AddText(ImGui::GetFont(), 13, ImVec2(x-9, y+32), model.isbon.Head  || model.isbon.neck ||  model.isbon.spine_3 || model.isbon.spine_2 || model.isbon.spine_1 || model.isbon.clavicle_l || model.isbon.upperarm_l || model.isbon.lowerarm_l || model.isbon.lowerarm_l || model.isbon.clavicle_r || model.isbon.upperarm_r || model.isbon.lowerarm_r || model.isbon.pelvis || model.isbon.thigh_l || model.isbon.calf_l || model.isbon.thigh_r || model.isbon.calf_r ? Green : Red, mi);
                                     }
                                 }
 }
     /*
                              人物骨骼
                              */
                         
                         
                           if(show_guge){
                                       
                                   
                                       
                                  draw_list->AddLine(ImVec2(model.bon.Head.X, model.bon.Head.Y), ImVec2(model.bon.neck.X, model.bon.neck.Y), model.isbon.Head ? Green : Red);
                                   ///没一个 判断不一样 自己看
                                       draw_list->AddLine(ImVec2(model.bon.neck.X, model.bon.neck.Y), ImVec2(model.bon.spine_3.X, model.bon.spine_3.Y), model.isbon.neck ? Green : Red);
                                   //                        //盆骨》左盆骨》左膝盖》左脚
                                   
                                   draw_list->AddLine(ImVec2(model.bon.spine_3.X, model.bon.spine_3.Y), ImVec2(model.bon.spine_2.X, model.bon.spine_2.Y), model.isbon.spine_3 ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.spine_2.X, model.bon.spine_2.Y), ImVec2(model.bon.spine_1.X, model.bon.spine_1.Y), model.isbon.spine_2 ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.spine_1.X, model.bon.spine_1.Y), ImVec2(model.bon.pelvis.X, model.bon.pelvis.Y), model.isbon.spine_1 ? Green : Red);
                                   //                        //盆骨》右盆骨》右膝盖》右脚
                                   draw_list->AddLine(ImVec2(model.bon.spine_3.X, model.bon.spine_3.Y), ImVec2(model.bon.clavicle_l.X, model.bon.clavicle_l.Y), model.isbon.spine_3 ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.clavicle_l.X, model.bon.clavicle_l.Y), ImVec2(model.bon.upperarm_l.X, model.bon.upperarm_l.Y), model.isbon.clavicle_l ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.upperarm_l.X, model.bon.upperarm_l.Y), ImVec2(model.bon.lowerarm_l.X, model.bon.lowerarm_l.Y), model.isbon.upperarm_l ? Green : Red);
                                   
                                   //                        //右手》右手肘》右肩膀》左肩膀》左手肘》左手
                                   draw_list->AddLine(ImVec2(model.bon.lowerarm_l.X, model.bon.lowerarm_l.Y), ImVec2(model.bon.hand_l.X, model.bon.hand_l.Y), model.isbon.lowerarm_l ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.spine_3.X, model.bon.spine_3.Y), ImVec2(model.bon.clavicle_r.X, model.bon.clavicle_r.Y), model.isbon.spine_3 ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.clavicle_r.X, model.bon.clavicle_r.Y), ImVec2(model.bon.upperarm_r.X, model.bon.upperarm_r.Y), model.isbon.clavicle_r ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.upperarm_r.X, model.bon.upperarm_r.Y), ImVec2(model.bon.lowerarm_r.X, model.bon.lowerarm_r.Y), model.isbon.upperarm_r ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.lowerarm_r.X, model.bon.lowerarm_r.Y), ImVec2(model.bon.hand_r.X, model.bon.hand_r.Y), model.isbon.lowerarm_r ? Green : Red);
                                   
                                   //
                                   draw_list->AddLine(ImVec2(model.bon.pelvis.X, model.bon.pelvis.Y), ImVec2(model.bon.thigh_l.X, model.bon.thigh_l.Y), model.isbon.pelvis ? Green : Red);
                                   
                                   
                                   draw_list->AddLine(ImVec2(model.bon.thigh_l.X, model.bon.thigh_l.Y), ImVec2(model.bon.calf_l.X, model.bon.calf_l.Y), model.isbon.thigh_l ? Green : Red);
                                   
                                   //
                                   draw_list->AddLine(ImVec2(model.bon.calf_l.X, model.bon.calf_l.Y), ImVec2(model.bon.foot_l.X, model.bon.foot_l.Y), model.isbon.calf_l ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.pelvis.X, model.bon.pelvis.Y), ImVec2(model.bon.thigh_r.X, model.bon.thigh_r.Y), model.isbon.pelvis ? Green : Red);
                                   
                                   draw_list->AddLine(ImVec2(model.bon.thigh_r.X, model.bon.thigh_r.Y), ImVec2(model.bon.calf_r.X, model.bon.calf_r.Y), model.isbon.thigh_r ? Green : Red);
                                   
                                   //盆骨》右盆骨》右膝盖》右脚
                                   draw_list->AddLine(ImVec2(model.bon.calf_r.X, model.bon.calf_r.Y), ImVec2(model.bon.foot_r.X, model.bon.foot_r.Y), model.isbon.calf_r ? Green : Red);
                                   }
    
    // Rendering
    ImGui::Render();
    ImDrawData* draw_data = ImGui::GetDrawData();
    ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
    
    
    [renderEncoder popDebugGroup];
    [renderEncoder endEncoding];
    
    [commandBuffer presentDrawable:view.currentDrawable];
}


[commandBuffer commit];

JHCJInfoStringTools *tools = [JHCJInfoStringTools tools];


}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}




- (void)doThe1Jo1b
{
    [[YYYYY data] AADARA:^(NSArray * _Nonnull infoArray,CGPoint aimPos) {
        [self configWithData :infoArray:infoArray aimPos:aimPos];
    }];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{

}
//}
#pragma mark  提示条
-(void)showMessage:(NSString *)message duration:(NSTimeInterval)time
{
    CGSize screenSize = [[UIScreen mainScreen] bounds].size;
    
    UIWindow * window = [UIApplication sharedApplication].keyWindow;
    UIView *showview =  [[UIView alloc]init];
    showview.backgroundColor = [UIColor whiteColor];
    showview.frame = CGRectMake(1, 1, 1, 1);
    showview.alpha = 1.0f;
    showview.layer.cornerRadius = 5.0f;
    showview.layer.masksToBounds = YES;
    [window addSubview:showview];
    
    UILabel *label = [[UILabel alloc]init];
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
    
    NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:15.f],
                                 NSParagraphStyleAttributeName:paragraphStyle.copy};
    
    CGSize labelSize = [message boundingRectWithSize:CGSizeMake(207, 999)
                                             options:NSStringDrawingUsesLineFragmentOrigin
                                          attributes:attributes context:nil].size;
    
    label.frame = CGRectMake(10, 5, labelSize.width +20, labelSize.height);
    label.text = message;
    label.textColor = [UIColor blackColor];
    //    label.textAlignment = 1;
    label.backgroundColor = [UIColor whiteColor];
    label.font = [UIFont boldSystemFontOfSize:15];
    [showview addSubview:label];
    
    showview.frame = CGRectMake((screenSize.width - labelSize.width - 20)/2,
                                screenSize.height - 300,
                                labelSize.width+40,
                                labelSize.height+10);
    [UIView animateWithDuration:time animations:^{
        showview.alpha = 0;
    } completion:^(BOOL finished) {
        [showview removeFromSuperview];
    }];
}
@end

