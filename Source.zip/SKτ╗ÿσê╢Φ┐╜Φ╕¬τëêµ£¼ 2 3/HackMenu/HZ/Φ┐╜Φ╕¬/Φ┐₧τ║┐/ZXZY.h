
#ifndef ______h
#define ______h


#endif /* ______h */

//#import
/*
extern BOOL LJ;
extern BOOL hook;
extern BOOL OFF;

@interface Constants : NSObject {
    
}
@end*/

