/*
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ZXZY.h"

BOOL LJ = NO;
BOOL hook = NO;
BOOL OFF = YES;
@implementation Constants
@end

*/
