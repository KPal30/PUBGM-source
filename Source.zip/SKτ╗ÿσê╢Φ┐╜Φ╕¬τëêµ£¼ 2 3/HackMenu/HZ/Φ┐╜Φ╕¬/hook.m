
#import <mach-o/dyld.h>
#import "Hook.h"
#import <UIKit/UIKit.h>
#import <sys/sysctl.h>
#import <arm_neon.h>
#import <CommonCrypto/CommonDigest.h>
#import "dobby.h"

@interface Hook ()
@property(nonatomic,strong)NSData *headtData;

@end
BOOL fanwei=YES;
float SK=600000;
@implementation Hook



+ (instancetype)shareInstance{
    static Hook *a = nil;
    if (!a) {
        a = [[Hook alloc] init];
    }
    return a;
}

//   void zz_handler(RegisterContext *rs, const HookEntryInfo *info);
//   void zz_handler(RegisterContext *rs, const HookEntryInfo *info){
//        if([Hook shareInstance].x!=0){
//                *(float *)(&rs->floating.regs.q0)=    [Hook shareInstance].x;
//                *(float *)(&rs->floating.regs.q1)=    [Hook shareInstance].y;
//                *(float *)(&rs->floating.regs.q2)=    [Hook shareInstance].z;
//            }
//
//        }
  void fw_handler(RegisterContext *rs, const HookEntryInfo *info);
  void fw_handler(RegisterContext *rs, const HookEntryInfo *info){
        if(fanwei == YES){

            if((*(float*)(rs->general.regs.x20+0x90)) == 28){
                *(float*)(rs->general.regs.x20+0x90) = SK ;

        }

        }


    }



void zz_handler(RegisterContext *rs, const HookEntryInfo *info);
void zz_handler(RegisterContext *rs, const HookEntryInfo *info){
    
    if([Hook shareInstance].x!=0) {
        *(float *)(&rs->floating.regs.q0)=    [Hook shareInstance].x;
        *(float *)(&rs->floating.regs.q1)=    [Hook shareInstance].y;
        *(float *)(&rs->floating.regs.q2)=    [Hook shareInstance].z;
    }
    
}
static float (*orig_lnstanthit)(int64_t a1, float32x4_t *a2, int64_t a3, int64_t a4, float result);
static float function_lnstanthit(int64_t a1, float32x4_t *a2, int64_t a3, int64_t a4, float result)
{
    float speed = result;

    if (speed == 91000.00000f ||   //AWM
        speed == 16000.00000f ||   //十字努
        speed == 84000.00000f ||   //SLR射手步枪
        speed == 76000.00000f ||   //98K
        speed == 76000.00000f ||   //Win94狙击抢
        speed == 79000.00000f ||   //M24狙击枪
        speed == 85300.00000f ||   //MK14狙击枪
        speed == 99000.00000f ||   //Mini14射手步枪
        speed == 80000.00000f      //SKS狙击枪
        )
    {
        result = 990000;
    }
    else if (
             speed == 71500.00000f ||    //AK
             speed == 71500.00000f ||    //R1895
             speed == 71500.00000f ||    //狗杂
             speed == 71500.00000f ||    //DP轻机枪
             speed == 94500.00000f ||    //QBU射手步枪
             speed == 87000.00000f ||    //QBZ突击步枪
             speed == 94000.00000f ||    //QUG突击步枪
             speed == 91500.00000f ||    //M249轻机枪
             speed == 88000.00000f ||    //M416突击步枪
             speed == 90000.00000f ||    //M16A4突击步枪
             speed == 87000.00000f ||    //SCAR-L突击步枪
             speed == 68000.00000f       //M762突击步枪
             )
    {
        result = 990000;
    }
    else if (
             speed == 36000.00000f ||    //S1987散弹枪
             speed == 37000.00000f ||    //S686散弹枪
             speed == 35000.00000f ||    //S12K散弹枪
             speed == 33000.00000f ||    //短管散弹枪
             speed == 33000.00000f ||    //VSS射手步枪
             speed == 40000.00000f ||    //UMP9冲锋枪
             speed == 35000.00000f ||    //UZI冲锋枪
             speed == 37500.00000f ||    //P18C冲锋枪
             speed == 38000.00000f ||    //P92冲锋枪
             speed == 28000.00000f ||    //汤姆逊冲锋枪
             speed == 30000.00000f ||    //Vector冲锋枪
             speed == 30000.00000f ||    //R45手枪
             speed == 25000.00000f ||    //P1911手枪)
             speed == 33000.00000f       //R1895手枪
             )
    {
        result = 990000;
    }

    float ret = orig_lnstanthit(a1, a2, a3, a4, result);
    return ret;
}

//追踪：0x1041F0F24
//范围：0x105ED7CA4
//瞬击：0x103CAC060
+(void)load{
  unsigned long sub_bss = ((unsigned long)_dyld_get_image_vmaddr_slide(0)) + 0x1041F0F24;
    DobbyInstrument((void *)sub_bss, zz_handler);
    
    unsigned long fw = (_dyld_get_image_vmaddr_slide(0) + 0x105ED7CA4 );
              DobbyInstrument((void *)fw, fw_handler);

    DobbyHook((void *)((unsigned long)_dyld_get_image_vmaddr_slide(0) + 0x103CAC060), (void *)function_lnstanthit, (void **)&orig_lnstanthit);
}
static __attribute__((constructor)) void _logosLocalCtor_02e74f10(int __unused argc, char __unused **argv, char __unused **envp);



@end

