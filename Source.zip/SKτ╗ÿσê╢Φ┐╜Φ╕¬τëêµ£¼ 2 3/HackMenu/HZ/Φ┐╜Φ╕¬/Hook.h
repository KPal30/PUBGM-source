//QQ97184668

#import <Foundation/Foundation.h>
#import "Hook.h"
#import <UIKit/UIKit.h>
//#import "YINSocket.h"

extern BOOL kaiqi;
extern BOOL kaiqi1;
//extern BOOL dongtai;

extern float SK;
extern BOOL fanwei;
@interface Hook : NSObject
{
  const  struct mach_header *header;
   char *colordata;
}

+ (instancetype)shareInstance;

@property(nonatomic,assign)NSInteger x;
@property(nonatomic,assign)NSInteger y;
@property(nonatomic,assign)NSInteger z;
@end
