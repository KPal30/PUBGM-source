//
//  JHCJDrawDataFactory.m
//  JHCJDraw
//
//  Created by 佚名 on 2021/1/8.
//

#import "JHCJDrawDataFactory.h"
#import <UIKit/UIKit.h>
#import <stdio.h>
#import <mach-o/dyld.h>
#import <mach/vm_region.h>
#import <malloc/malloc.h>
#import <objc/runtime.h>
#import <mach/mach.h>
#include "string"
#import "JHCJInfoModel.h"
#import <sys/socket.h>
#import <Foundation/Foundation.h>
#import <mach/mach_traps.h>


#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

float matrixdataa[16];
using namespace std;
struct ObjectName{
    const char data[64];
};

long YawAndPitch;
long myActora = 0;


#pragma mark - 骨骼计算公式


@interface JHCJDrawDataFactorya()
@property (nonatomic,  assign) CGFloat  scale;
@property (nonatomic,  assign) CGFloat  theWidth;
@property (nonatomic,  assign) CGFloat  theHeight;

@property (nonatomic,  strong) NSMutableArray *usedModes;
@property (nonatomic,  strong) NSMutableArray *cacheModes;

@end

@implementation JHCJDrawDataFactorya

+ (instancetype)factory
{
    static JHCJDrawDataFactorya *fact;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        fact = [[JHCJDrawDataFactorya alloc] init];
    });
    return fact;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        UIScreen *screen = [UIScreen mainScreen];
        CGFloat width  = screen.bounds.size.width;
        CGFloat height = screen.bounds.size.height;
        
        _scale = screen.scale;
        _theWidth = width * [UIScreen mainScreen].scale;
        _theHeight = height * [UIScreen mainScreen].scale;
        
        self.cacheModes = [NSMutableArray array];
        self.usedModes = [NSMutableArray array];
    }
    return self;
}

#pragma mark - private

- (BOOL)vmreadData:(void *)buf address:(long)address length:(long)length
{
    vm_size_t size = 0;
    kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)address, length, (vm_address_t)buf, &size);
    if(error != KERN_SUCCESS || size != length){
        return NO;
    }
    return YES;
}

- (Vector)wordToScreen:(Vector)vector matrix:(float *)matrix
{
    struct Vector outVec = {3100,3100};
    
    // 矩阵,世界坐标转换屏幕坐标
    float view = matrix[3] * vector.X + matrix[7] * vector.Y + matrix[11] * vector.Z + matrix[15];
    float x,y,z;
    
    if (view < 0.01) {
        z = matrix[8] * vector.X + matrix[9] * vector.Y + matrix[10] * vector.Z + matrix[11];
        x = _theWidth + (matrix[0] * vector.X + matrix[4] * vector.Y + matrix[8] * vector.Z + matrix[12]) / 2 * _theWidth;
        y = _theHeight - (matrix[1] * vector.X + matrix[5] * vector.Y + matrix[9] * vector.Z + matrix[13]) / 2 * _theHeight;
    }else{
        z = matrix[3] * vector.X + matrix[7] * vector.Y + matrix[11] * vector.Z + matrix[15];
        x = _theWidth + (matrix[0] * vector.X + matrix[4] * vector.Y + matrix[8] * vector.Z + matrix[12]) / z * _theWidth;
        y = _theHeight - (matrix[1] * vector.X + matrix[5] * vector.Y + matrix[9] * vector.Z + matrix[13]) / z * _theHeight;
    }
    
    outVec.X = x/2/_scale;
    outVec.Y = y/2/_scale;
    
    return outVec;
}

#pragma mark - private

- (JHCJInfoModel*)fetchNextMode {
    JHCJInfoModel *model = [self.cacheModes firstObject];
    
    if (!model) {
        model = [JHCJInfoModel new];
    }
    
    [self.usedModes addObject:model];
    [self.cacheModes removeObject:model];
    
    return model;
}

#pragma mark - public

- (void)fetchData:(JHCJDrawDataFactoryaFetchDataBlock)block
{
    NSMutableArray *infoArray = @[].mutableCopy;
    
    CGPoint markScreenPos = CGPointMake(kScreenWidth/2, kScreenHeight/2);
    
    long gname = *(long*)((unsigned long)_dyld_get_image_vmaddr_slide(0) + 0x10A56BC98);
    if(!gname || gname < 0x100000000 || gname > 0x200000000) {
        return;
    }
    long matrix_data = *(long*)((unsigned long)_dyld_get_image_vmaddr_slide(0) + 0x109C92A38);
    if(!matrix_data || matrix_data < 0x100000000 || matrix_data > 0x200000000) {
        return;
    }
    long matrix_data_2 = *(long*)(matrix_data + 0x98);
    if(!matrix_data_2 || matrix_data_2 < 0x100000000 || matrix_data_2 > 0x200000000) {
        return;
    }
    Vector mylnfo = {0};
    [self vmreadData:&mylnfo address:(matrix_data_2 + 0x740) length:12];
    
    float* matrix_data_3 = (float*)(matrix_data_2 + 0x750);
    [self vmreadData:matrixdataa address:(long)matrix_data_3 length:16*4];
    
    long gworld = *(long*)((unsigned long)_dyld_get_image_vmaddr_slide(0) + 0x10A8CF890);
    if(!gworld|| gworld < 0x100000000 || gworld > 0x200000000) {
        return;
    }
    long plevel = *(long*)(gworld + 0x30);
    if(!plevel|| plevel < 0x100000000 || plevel > 0x200000000) {
        return;
    }
    int max = *(int*)(plevel + 0xAC);
    int count = *(int*)(plevel + 0xA8);
    long actors = *(long*)(plevel + 0xA0);
    if(!actors || actors < 0x100000000 || actors > 0x200000000) {
        return;
    }
    if(!(actors && count > 0 && count < max)) {
        return;
    }
    for (int i = 0; i < count; i++) {

        long objectpointer = ((long*)actors)[i];
        if(!objectpointer || objectpointer < 0x100000000 || objectpointer > 0x200000000 ) continue;
        
        long scenecomponent = *(long*)(objectpointer + 0x1d8);
        if(!scenecomponent|| scenecomponent > 0x200000000 || scenecomponent < 0x100000000 ) continue;
        Vector objlnfo = {0};
        [self vmreadData:&objlnfo address:(scenecomponent + 0x1c0) length:12];
        
        // 资源名读取
        int32_t class_id = *(int32_t*)(objectpointer + 0x18);
        long fNamePtr = *(long*)(gname + int(class_id / 0x4000) * 0x8);
        if(!fNamePtr || fNamePtr > 0x200000000 || fNamePtr < 0x100000000) continue;
        long fName = *(long*)(fNamePtr + int(class_id % 0x4000) * 0x8);
        if(!fName || fName > 0x200000000 || fName < 0x100000000) continue;
        
        ObjectName pBuffer = *(ObjectName*)(fName + 0xe);
        std::string bpname = pBuffer.data;
        NSString *ClassName= [NSString stringWithCString:bpname.c_str() encoding:[NSString defaultCStringEncoding]];
        
        // 对象距离
        CGFloat dist_x = (objlnfo.X - mylnfo.X) / 100;
        CGFloat dist_y = (objlnfo.Y - mylnfo.Y) / 100;
        CGFloat dist_z = (objlnfo.Z - mylnfo.Z) / 100;
        
        CGFloat distance = (dist_x * dist_x) + (dist_y * dist_y);
        distance = sqrt((dist_z * dist_z) + distance);

        /* 15 = 药包 */
         if ([ClassName containsString:@"Firstaid_Pickup_"]) {
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 15;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 16 = 急救箱 */
        else if ([ClassName containsString:@"FirstAidbox_Pickup_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 16;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 17 = 能量饮料 */
        else if ([ClassName containsString:@"Drink_Pickup_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 17;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 18 = 肾上腺素 */
        else if ([ClassName containsString:@"Injection_Pickup_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 18;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 19 = 止痛药 */
        else if ([ClassName containsString:@"Pills_Pickup_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 19;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 20 = 三级包 */
        else if ([ClassName containsString:@"PickUp_BP_Bag_Lv3_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 20;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 21 = 三级甲 */
        else if ([ClassName containsString:@"PickUp_BP_Armor_Lv3_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 21;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 22 = 三级头 */
        else if ([ClassName containsString:@"PickUp_BP_Helmet_Lv3_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 22;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 23 = 燃烧瓶 */
        else if ([ClassName containsString:@"BP_Grenade_Burn_Weapon_Wrapper_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 23;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 24 = 烟雾弹 */
        else if ([ClassName containsString:@"BP_Grenade_Smoke_Weapon_Wrapper_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 24;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 25 = 手雷 */
        else if ([ClassName containsString:@"BP_Grenade_Shoulei_Weapon_Wrapper_"]){
            if (distance > 2 && distance <= 20) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 25;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 251 = 拉手雷 */
        else if ([ClassName containsString:@"BP_Grenade_Shoulei_C"]){
            if (distance > 2 && distance <= 50) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 251;
                model.distance = distance;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 26 = 蹦蹦 */
        else if ([ClassName containsString:@"BP_VH_Buggy_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 26;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 27 = 吉普 */
        else if ([ClassName containsString:@"VH_UAZ"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 27;
                model.distance = distance;
                model.rect = rect;
                [infoArray addObject:model];
            }
        }
        
        /* 28 = 跑车 */
        else if ([ClassName containsString:@"Mirado_close_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 28;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 281 = 跑车 */
        else if ([ClassName containsString:@"Mirado_open_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 281;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 29 = 轿车 */
        else if ([ClassName containsString:@"VH_Dacia_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 29;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 30 = 小摩托车 */
        else if ([ClassName containsString:@"VH_Scooter_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 30;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 31 = 火货车 */
        else if ([ClassName containsString:@"Rony_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 31;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 32 = 小巴 */
        else if ([ClassName containsString:@"VH_MiniBus_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 32;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 33 = 雪地车 */
        else if ([ClassName containsString:@"VH_Snowmobile_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 33;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 34 = 船 */
        else if ([ClassName containsString:@"VH_PG117_"]){
            if (distance > 10 && distance <= 200) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 34;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 35 = 摩托车 */
        else if ([ClassName containsString:@"VH_Motorcycle_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 35;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 36 = 三轮摩托 */
        else if ([ClassName containsString:@"VH_MotorcycleCart_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 36;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        /* 361 = 三轮车 */
        else if ([ClassName containsString:@"BP_VH_Tuk_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 361;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 37 = 两栖装甲车 */
        else if ([ClassName containsString:@"VH_BRDM_"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 37;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 38 = 皮卡 */
        else if ([ClassName containsString:@"PickUp_0"]){
            if (distance > 10 && distance <= 600) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 38;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 39 = 冲锋艇 */
        else if ([ClassName containsString:@"AquaRail_"]){
            if (distance > 10 && distance <= 200) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 39;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 40 = 空投 */
        else if ([ClassName containsString:@"BP_AirDrop"]||
                 [ClassName containsString:@"AirDropListWrapperActor"]){
            if (distance > 1 && distance <= 1000) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 40;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 41 = 盒子 */
        else if ([ClassName containsString:@"PlayerDeadInventoryBox_"]){
            if (distance > 2 && distance <= 25) {
                
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 41;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 42 = M4 *///BP_Rifle_M416_C持枪//BP_Rifle_M416_Wrapper_//BP_Rifle_M416_Wrapper_C
        else if ([ClassName containsString:@"BP_Rifle_M416_Wrapper_"]){
            if (distance > 10 && distance <= 100) {
                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 42;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 43 = AK */
        else if ([ClassName containsString:@"BP_Rifle_AKM_Wrapper_"]){
            if (distance > 10 && distance <= 100) {

                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 43;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        
        /* 44 = M762 */
        else if ([ClassName containsString:@"BP_Rifle_M762_Wrapper_"]){
            if (distance > 10 && distance <= 100) {

                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 44;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        /* 45 = SCAR */
        else if ([ClassName containsString:@"BP_Rifle_SCAR_Wrapper_"]){
            if (distance > 10 && distance <= 35) {

                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 45;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        /* 46 = 3倍 */
        else if ([ClassName containsString:@"BP_MZJ_3X_Pickup_"]){
            if (distance > 10 && distance <= 35) {

                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 46;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        /* 47 = 4倍 */
        else if ([ClassName containsString:@"BP_MZJ_4X_Pickup_"]){
            if (distance > 10 && distance <= 35) {

                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 47;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
        /* 48 = 6倍 */
        else if ([ClassName containsString:@"BP_MZJ_6X_Pickup_"]){
            if (distance > 10 && distance <= 35) {

                Vector objlnfo_1 = objlnfo;
                objlnfo_1.Z += 0;
                
                Vector objlnfo_2 = objlnfo;
                objlnfo_2.Z -= 0;
                
                Vector fkzb1 = [self wordToScreen:objlnfo_1 matrix:matrix_data_3];
                if (fkzb1.X <= 0 || fkzb1.X > kScreenWidth)
                    continue;
                Vector fkzb2 = [self wordToScreen:objlnfo_2 matrix:matrix_data_3];
                
                float height = fkzb2.Y - fkzb1.Y;
                float width  = height / 2;
                
                float originX = fkzb1.X - width / 2;
                float originY = fkzb1.Y;
                
                CGRect rect = CGRectMake(originX, originY, width, height);
                
                JHCJInfoModel *model = [self fetchNextMode];
                model.flag = 48;
                model.rect = rect;
                model.distance = distance;
                [infoArray addObject:model];
            }
        }
    }
    
    if (block) {
        block(infoArray, markScreenPos);
    }
}

@end
