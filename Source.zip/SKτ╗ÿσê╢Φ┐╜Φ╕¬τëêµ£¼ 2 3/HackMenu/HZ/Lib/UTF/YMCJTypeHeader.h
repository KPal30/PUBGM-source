//
//  YMCJTypeHeader.h
//  Test
//
//  Created by yiming on 2021/5/19.
//  Copyright © 2021 yiming. All rights reserved.
//

#ifndef YMCJTypeHeader_h
#define YMCJTypeHeader_h

#include <arm_neon.h>

typedef struct Vector{
    float X;
    float Y;
    float Z;
}Vector;

#endif /* YMCJTypeHeader_h */
