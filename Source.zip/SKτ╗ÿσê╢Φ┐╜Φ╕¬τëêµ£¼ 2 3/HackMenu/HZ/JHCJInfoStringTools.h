//
//  JHCJInfoStringTools.h
//  libCJHookDylib
//
//  Created by 李良林 on 2021/3/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface JHCJInfoStringTools : NSObject

+ (JHCJInfoStringTools*)tools;

- (NSString*)nameStringForNumber:(NSUInteger)number;
- (NSString*)nameWithAIName:(NSString*)name;
- (NSString*)nameWithName:(NSString *)name;
- (NSString*)distanceStringWithDistance:(int)distance;
//- (NSString*)hpStringWith:(int)hp;

@end

NS_ASSUME_NONNULL_END
