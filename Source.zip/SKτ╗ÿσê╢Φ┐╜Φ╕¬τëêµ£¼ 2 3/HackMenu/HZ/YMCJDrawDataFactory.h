//
//
//  YMCJDrawDataFactory.h
//  Test
//
//  Created by yiming on 2021/5/19.
//  Copyright © 2021 yiming. All rights reserved.
//

#import <Foundation/Foundation.h>
#define kAimRadius   90
#import "YMCJDrawDataFactory.h"



NS_ASSUME_NONNULL_BEGIN

typedef void (^xcoddataFetchDataBlock)(NSArray *infoArray,CGPoint markScreenPos);

@interface YYYYY : NSObject

+ (instancetype)data;
- (void)show;
+ (void)showChange:(BOOL)open;
- (void)AADARA:(xcoddataFetchDataBlock)block;
@end

NS_ASSUME_NONNULL_END
