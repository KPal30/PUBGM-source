//
//  VMPatchOffsetTool.h
//  BeautyListSwift
//
//  Created by 李良林 on 2020/11/17.
//  Copyright © 2020 李良林. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface private_VMPatchOffsetTool : NSObject

@end

NS_ASSUME_NONNULL_END


