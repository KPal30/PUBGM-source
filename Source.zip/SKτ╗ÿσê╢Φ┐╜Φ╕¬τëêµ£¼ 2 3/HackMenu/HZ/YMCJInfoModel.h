//
//  YMCJInfoModel.h
//  Test
//
//  Created by yiming on 2021/5/19.
//  Copyright © 2021 yiming. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "YMCJTypeHeader.h"
#include "utf.h"

NS_ASSUME_NONNULL_BEGIN

@interface lnfCJisBon : NSObject
/// 头部
@property (nonatomic,  assign) bool  Head;
/// 脖子
@property (nonatomic,  assign) bool  neck;
/// 脊柱 3
@property (nonatomic,  assign) bool  spine_3;
/// 脊柱 2
@property (nonatomic,  assign) bool  spine_2;
/// 脊柱 1
@property (nonatomic,  assign) bool  spine_1;
/// 骨盆
@property (nonatomic,  assign) bool  pelvis;
/// 右锁骨
@property (nonatomic,  assign) bool  clavicle_r;
/// 右上臂
@property (nonatomic,  assign) bool  upperarm_r;
/// 右下臂
@property (nonatomic,  assign) bool  lowerarm_r;
/// 右手
@property (nonatomic,  assign) bool  hand_r;
/// 左锁骨
@property (nonatomic,  assign) bool  clavicle_l;
/// 左上臂
@property (nonatomic,  assign) bool  upperarm_l;
/// 左下臂
@property (nonatomic,  assign) bool  lowerarm_l;
/// 左手
@property (nonatomic,  assign) bool  hand_l;
/// 右大腿
@property (nonatomic,  assign) bool  thigh_r;
/// 右小牛
@property (nonatomic,  assign) bool  calf_r;
/// 右脚
@property (nonatomic,  assign) bool  foot_r;
/// 左大腿
@property (nonatomic,  assign) bool  thigh_l;
/// 左小牛
@property (nonatomic,  assign) bool  calf_l;
/// 左脚
@property (nonatomic,  assign) bool  foot_l;
@end

@interface lnfCJInfoBon : NSObject
/// 头部
@property (nonatomic,  assign) Vector  Head;
/// 脖子
@property (nonatomic,  assign) Vector  neck;
/// 脊柱 3
@property (nonatomic,  assign) Vector  spine_3;
/// 脊柱 2
@property (nonatomic,  assign) Vector  spine_2;
/// 脊柱 1
@property (nonatomic,  assign) Vector  spine_1;
/// 骨盆
@property (nonatomic,  assign) Vector  pelvis;
/// 右锁骨
@property (nonatomic,  assign) Vector  clavicle_r;
/// 右上臂
@property (nonatomic,  assign) Vector  upperarm_r;
/// 右下臂
@property (nonatomic,  assign) Vector  lowerarm_r;
/// 右手
@property (nonatomic,  assign) Vector  hand_r;
/// 左锁骨
@property (nonatomic,  assign) Vector  clavicle_l;
/// 左上臂
@property (nonatomic,  assign) Vector  upperarm_l;
/// 左下臂
@property (nonatomic,  assign) Vector  lowerarm_l;
/// 左手
@property (nonatomic,  assign) Vector  hand_l;
/// 右大腿
@property (nonatomic,  assign) Vector  thigh_r;
/// 右小牛
@property (nonatomic,  assign) Vector  calf_r;
/// 右脚
@property (nonatomic,  assign) Vector  foot_r;
/// 左大腿
@property (nonatomic,  assign) Vector  thigh_l;
/// 左小牛
@property (nonatomic,  assign) Vector  calf_l;
/// 左脚
@property (nonatomic,  assign) Vector  foot_l;
@end

@interface lnfCJInfoModel : NSObject
/// 队编
@property (nonatomic,  assign) NSInteger number;
/// 名称
@property (nonatomic,    copy) NSString *name;
/// 距离
@property (nonatomic,  assign) CGFloat  distance;
///
@property (nonatomic,  assign) CGFloat  distanc;
///
/// 血量
@property (nonatomic,  assign) CGFloat  hp;
/// 方框
@property (nonatomic,  assign) CGRect  rect;
/// AI，1是人机，0是真人
@property (nonatomic,  assign) BOOL  isAI;
/// 骨架
@property (nonatomic,  assign) NSInteger flag;
///
@property (nonatomic,  strong) lnfCJInfoBon *bon;
///
@property (nonatomic,  strong) lnfCJisBon *isbon;

///
+ (NSString *)getName:(const UTF16*)sourceStart t:(UTF8*)targetStart l:(size_t)outLen f:(ConversionFlags)flags;

@end

extern int Utf16_To_Utf8 (const UTF16* sourceStart, UTF8* targetStart, size_t outLen ,  ConversionFlags flags);

NS_ASSUME_NONNULL_END
