///
//  libgetespdata.m
//  sssimgui
//
//  Created by 樱花 on 2021/9/20.
//  Copyright © 2021 樱花. All rights reserved.
//
//#import "ZXZY.h"
#import "ZQTColorSwitch.h"
#import "YMCJDrawDataFactory.h"
#import "mach-o/loader.h"
#import <UIKit/UIKit.h>
#import <stdio.h>
#import <mach-o/dyld.h>
#import <mach/vm_region.h>
#import <malloc/malloc.h>
#import <objc/runtime.h>
#import <mach/mach.h>
#import "utf.h"

#import <Foundation/Foundation.h>
#import <mach/mach_traps.h>
#import <sys/socket.h>
#include "string"
#import "YMCJTypeHeader.h"
#import "YMCJInfoModel.h"
#import "YMCJVectorHeader.h"
#import "dobby.h"
#import "GlobalVariable.h"
#define kScreenWidth  [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale
float screenx = 1024;
float screeny = 768;
float matrixdata[16];


struct ObjectName{
    

    const char data[64];
};

CVector3 aimhead;
//kaddr PlayerCameraManager;
long myActor = 0;
BOOL Dis = true;
@interface YYYYY()
@property (nonatomic,  assign) CGFloat  scale;
@property (nonatomic,  assign) CGFloat  theWidth;
@property (nonatomic,  assign) CGFloat  theHeight;

@end
@implementation YYYYY
BOOL needAdjustAim = false;
#pragma mark --⻣骼数据计算公式
LTMatrix MatrixMultiplication(LTMatrix pM1, LTMatrix pM2); LTMatrix MatrixMultiplication(LTMatrix pM1, LTMatrix pM2) {
LTMatrix pOut;
pOut.a1 = pM1.a1 * pM2.a1 + pM1.a2 * pM2.b1 + pM1.a3 * pM2.c1 + pM1.a4 * pM2.d1; pOut.a2 = pM1.a1 * pM2.a2 + pM1.a2 * pM2.b2 + pM1.a3 * pM2.c2 + pM1.a4 * pM2.d2; pOut.a3 = pM1.a1 * pM2.a3 + pM1.a2 * pM2.b3 + pM1.a3 * pM2.c3 + pM1.a4 * pM2.d3; pOut.a4 = pM1.a1 * pM2.a4 + pM1.a2 * pM2.b4 + pM1.a3 * pM2.c4 + pM1.a4 * pM2.d4; pOut.b1 = pM1.b1 * pM2.a1 + pM1.b2 * pM2.b1 + pM1.b3 * pM2.c1 + pM1.b4 * pM2.d1; pOut.b2 = pM1.b1 * pM2.a2 + pM1.b2 * pM2.b2 + pM1.b3 * pM2.c2 + pM1.b4 * pM2.d2; pOut.b3 = pM1.b1 * pM2.a3 + pM1.b2 * pM2.b3 + pM1.b3 * pM2.c3 + pM1.b4 * pM2.d3; pOut.b4 = pM1.b1 * pM2.a4 + pM1.b2 * pM2.b4 + pM1.b3 * pM2.c4 + pM1.b4 * pM2.d4; pOut.c1 = pM1.c1 * pM2.a1 + pM1.c2 * pM2.b1 + pM1.c3 * pM2.c1 + pM1.c4 * pM2.d1; pOut.c2 = pM1.c1 * pM2.a2 + pM1.c2 * pM2.b2 + pM1.c3 * pM2.c2 + pM1.c4 * pM2.d2; pOut.c3 = pM1.c1 * pM2.a3 + pM1.c2 * pM2.b3 + pM1.c3 * pM2.c3 + pM1.c4 * pM2.d3; pOut.c4 = pM1.c1 * pM2.a4 + pM1.c2 * pM2.b4 + pM1.c3 * pM2.c4 + pM1.c4 * pM2.d4; pOut.d1 = pM1.d1 * pM2.a1 + pM1.d2 * pM2.b1 + pM1.d3 * pM2.c1 + pM1.d4 * pM2.d1; pOut.d2 = pM1.d1 * pM2.a2 + pM1.d2 * pM2.b2 + pM1.d3 * pM2.c2 + pM1.d4 * pM2.d2; pOut.d3 = pM1.d1 * pM2.a3 + pM1.d2 * pM2.b3 + pM1.d3 * pM2.c3 + pM1.d4 * pM2.d3; pOut.d4 = pM1.d1 * pM2.a4 + pM1.d2 * pM2.b4 + pM1.d3 * pM2.c4 + pM1.d4 * pM2.d4;
return pOut; }
FTransform GetBoneIndex(const long mesh, int index); FTransform GetBoneIndex(const long mesh, int index) {
long v30 = *(long *)(mesh + 0x6d8); long boneBase = (v30 + 48LL * index);
FTransform result; if(boneBase>0x100000000){
result.rot.x = *(float*)(boneBase + 0x0); result.rot.y = *(float*)(boneBase + 0x4); result.rot.z = *(float*)(boneBase + 0x8); result.rot.w = *(float*)(boneBase + 0xC); CVector3 pos;
pos.x = *(float*)(boneBase + 0x10); pos.y = *(float*)(boneBase + 0x14); pos.z = *(float*)(boneBase + 0x18);
if (index == 6) {
if (pos.x <= -25.0f) {
result.translation.x = pos.x + (pos.x / 2); }
else if (pos.x >= 25.0f) {
result.translation.x = pos.x + (pos.x / 3.5); }
else {
result.translation.x = pos.x + (pos.x / 2); }
result.translation.y = pos.y + 12.0f;
result.translation.z = pos.z + 10.0f; }
else if (index == 4)
 {
result.translation.x = pos.x; result.translation.y = pos.y; result.translation.z = pos.z + 10.0f;;
} else {
result.translation.x = pos.x; result.translation.y = pos.y; result.translation.z = pos.z;
}
if (index == 4) {
result.translation.z += 10; }
result.scale.x = *(float*)(boneBase + 0x20); result.scale.y = *(float*)(boneBase + 0x24); result.scale.z = *(float*)(boneBase + 0x2C);
}
return result; }
static Vector GetBoneWithRotation(const long mesh, int id) //GetBoneWithRotation
{
Vector result;
FTransform bone = GetBoneIndex(mesh, id);
FTransform ComponentToWorld; ComponentToWorld.rot.x = Read_Float(mesh + 0x1b0); ComponentToWorld.rot.y = Read_Float(mesh + 0x1b4); ComponentToWorld.rot.z = Read_Float(mesh + 0x1b8); ComponentToWorld.rot.w = Read_Float(mesh + 0x1bc);
ComponentToWorld.translation.x = Read_Float(mesh + 0x1c0); ComponentToWorld.translation.y = Read_Float(mesh + 0x1c4); ComponentToWorld.translation.z = Read_Float(mesh + 0x1c8);
ComponentToWorld.scale.x = Read_Float(mesh + 0x1d0); ComponentToWorld.scale.y = Read_Float(mesh + 0x1d4); ComponentToWorld.scale.z = Read_Float(mesh + 0x1d8);
LTMatrix Matrix;
Matrix = MatrixMultiplication(bone.ToMatrixWithScale(), ComponentToWorld.ToMatrixWithScale());
result.X = Matrix.d1; result.Y = Matrix.d2; result.Z = Matrix.d3;
return result; }
+ (instancetype)data {
static YYYYY *fact;
static dispatch_once_t onceToken; dispatch_once(&onceToken, ^{
fact = [[YYYYY alloc] init]; });

 return fact; }
- (instancetype)init {
self = [super init]; if (self) {
UIScreen *screen = [UIScreen mainScreen]; CGFloat width = screen.bounds.size.width; CGFloat height = screen.bounds.size.height;
_scale = screen.scale;
_theWidth = width * [UIScreen mainScreen].scale; _theHeight = height * [UIScreen mainScreen].scale;
}
return self; }
#pragma mark - private
- (BOOL)vmreadData:(void *)buf address:(long)address length:(long)length {
vm_size_t size = 0;
kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)address, length, (vm_address_t)buf, &size);
if(error != KERN_SUCCESS || size != length){ return NO;
}
return YES; }
float GetDistance(float mx, float my, float mz, float ox, float oy, float oz) { float x,y,z;
x = mx - ox;
y = my - oy;
z = mz - oz;
return (float)(sqrt(x * x + y * y + z * z));
}
- (Vector)word2Screen:(Vector)vector matrix:(float *)matrix
{
    struct Vector outVec = {0,0};
    
    // 矩阵,世界坐标转换屏幕坐标
    float view = matrix[3] * vector.X + matrix[7] * vector.Y + matrix[11] * vector.Z + matrix[15];
    float x,y;
    
        if (view < 1.0/90) {
        // 背面
        x = _theWidth + (matrix[0] * vector.X + matrix[4] * vector.Y + matrix[8] * vector.Z + matrix[12]) / 2 * _theWidth;
        y = _theHeight - (matrix[1] * vector.X + matrix[5] * vector.Y + matrix[9] * vector.Z + matrix[13]) / 2 * _theHeight;
    }else {
        // 正面
        x = _theWidth + (matrix[0] * vector.X + matrix[4] * vector.Y + matrix[8] * vector.Z + matrix[12]) / view * _theWidth;
        y = _theHeight - (matrix[1] * vector.X + matrix[5] * vector.Y + matrix[9] * vector.Z + matrix[13]) / view * _theHeight;
    }
    
    outVec.X = x/2/_scale;
    outVec.Y = y/2/_scale;
//    outVec.X = x/2;
//    outVec.Y = y/2;
    
    return outVec;
}
#pragma mark - public
bool LineTrace(long Object,Vector End,long Controller,long GWorld)
{
if (Controller <= 0x100000000) return 0;
long imagevmaddr = _dyld_get_image_vmaddr_slide(0); MyObject = *(long*)(Controller + 0x400);
long PlayerCameraManager = Read_long(Controller+0x478); if (MyObject <= 0) return 0;
   

           
    int LineTraceData[100] = {0};
long IDLineOfSight = Read_long(imagevmaddr + 0x10A220E08);
Vector Start = Read_Vector(PlayerCameraManager + 0x470);
long Hit = imagevmaddr + 0x10A4BB548;
reinterpret_cast<void(*)(long,long,long,long,long)> (imagevmaddr+0x105EC7808) ((long)&LineTraceData[0],IDLineOfSight,(long)&LineTraceData[40],1,MyObject);
reinterpret_cast<void(*)(long,long)> (imagevmaddr+0x105ECB074)((long)&LineTraceData[0],Object);
int ret = reinterpret_cast<int(*)(long,Vector*,Vector*,long,long,long)>(imagevmaddr+0x105EDD978) (GWorld,&Start,&End,3,(long)&LineTraceData[0],Hit);
return (ret&0x1)==0; }
void ReadData(void* buff,long Address,int length) {
vm_size_t size = 0;
kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)Address, length, (vm_address_t)buff, &size);
if(error != KERN_SUCCESS || size != length){ return;
}
return; }
bool vmreadData(void* buff, long address, int length) {
vm_size_t size = 0;
kern_return_t error = vm_read_overwrite(mach_task_self(), (vm_address_t)address, length, (vm_address_t)buff, &size);
if(error != KERN_SUCCESS || size != length){ return false;
}
return true; }
int Read_Int(long Address) {
int result=0; ReadData(&result,Address,4); return result;
}
float Read_Float(long Address) {
float result=0; ReadData(&result,Address,4); return result;
}

 long Read_long(long Address) {
long result=0; ReadData(&result,Address,8); return result;
}
Vector Read_Vector(long Address) {
Vector result={0}; ReadData(&result,Address,12); return result;
}
long MyObject;
float getdis(Vector myob, Vector eyob);
float getdis(Vector myob, Vector eyob)//getDistance
{
    float x,y,z;
    x = myob.X - eyob.X;
    y = myob.Y - eyob.Y;
    z = myob.Z - eyob.Z;
return (float)(sqrt(x * x + y * y + z * z)/100);
}
- (double)toRad:(double)degrees{ return degrees*(M_PI/180);
}
NSUInteger CenterOffsetForVector(Vector point) {
return sqrt(pow(point.X - kScreenWidth/2.0, 2.0) + pow(point.Y - kScreenHeight/2, 2.0));
}
-(void)AADARA:(xcoddataFetchDataBlock)block{ NSMutableArray *infoArray = @[].mutableCopy; NSMutableArray *wuziArray = @[].mutableCopy;
//
// 弹道相关
float markDistance = kScreenWidth;
CGPoint markScreenPos = CGPointMake(kScreenWidth/2, kScreenHeight/2); float tDistance = 0;
float RDistance = aimRadius; if(aimRadius!=0){
peraim = true; }
CGRect kAimRect = CGRectMake(kScreenWidth/2 - aimRadius, kScreenHeight/2 - aimRadius,
aimRadius * 2, aimRadius * 2);
if(Speak){
aimhead.x = 0; aimhead.y = 0;
aimhead.z = 0;
}
long mh_addr = (long)_dyld_get_image_header(0);
long GName = *(long*)((unsigned long)_dyld_get_image_vmaddr_slide(0) +0x10A16C108);
if(!GName|| GName < 0x100000000 || GName > 0x200000000) return;
//矩阵数据
long matrix_data = Read_long(mh_addr + 0x0988F350); if(!matrix_data)return;

 long matrix_data2 = Read_long(matrix_data+0x98); if(!matrix_data2)return;
float* WordScreen = (float*)(matrix_data2 + 0x750);
[self vmreadData:matrixdata address:(long)WordScreen length:16*4];
Vector mylnfo = {0};
vmreadData(&mylnfo, (matrix_data2 + 0x740), 12);
//获取机制
long GWorld = Read_long(mh_addr + 0x0A4D34E0);//0x0A1C9260 if(!GWorld) return;
long PLevel = Read_long(GWorld + 0x30);//0x30 if(!PLevel) return;
int max = Read_Int(PLevel + 0xAC);//0xAC
int count = Read_Int(PLevel + 0xA8);//0xA8 '
    long Actors = Read_long(PLevel + 0xA0);//0xA0
if(!(Actors && count > 0 && count < max)) return; for (int i = 0; i < count; i++) {
long NetDriver = Read_long(GWorld + 0x38); if(!NetDriver) continue;
long ServerConnection = Read_long(NetDriver + 0x78); if(!ServerConnection) continue;
long OwningActor = Read_long(ServerConnection + 0x98); if(!OwningActor) continue;
long objectpointer = ((long*)Actors)[i];
if (!objectpointer|| objectpointer < 0x100000000) continue;
long objController = Read_long(objectpointer + 0x420); if (objController == OwningActor){
long whatever = Read_long(objectpointer + 0x718); if(whatever > 0x100000000 && whatever < 0x200000000) {
myActor = objectpointer; }
}
if(!myActor) continue;
long RootComponent = Read_long(objectpointer + 0x1d8); if (!RootComponent) continue;
Vector objlnfo = {0};

//
float xue = Read_Float(objectpointer + 0xba8); float xue2 = Read_Float(objectpointer + 0xbb0);
if(xue2 == 100) {
int Team = Read_Int(objectpointer+0x8c0); int MyTeam = Read_Int(myActor+0x8c0); if (Team == MyTeam) continue;
// 区分人机
long isAI = Read_long(objectpointer + 0x8dc);
// 死亡状态
Byte bDead = *(Byte*)(objectpointer + 0xc10); if(bDead != 2) continue;
long NamePointer = *(long*)(objectpointer + 0x850); if(!NamePointer) continue;
UTF8 PlayerName[32] = ""; UTF16 buf16[16] = {0};
NSString *name = @""; if (NamePointer) {
[self vmreadData:buf16 address:NamePointer length:28];
name = [lnfCJInfoModel getName:buf16 t:PlayerName l:28 f:strictConversion]; }
NSLog(@"*** Player Name : %@",name);
Vector zb = Read_Vector(RootComponent + 0x1C0);
long mesh = *(long*)(objectpointer + 0x470);
if(!mesh|| mesh > 0x2000000000 || mesh < 0x100000000) continue;
int Bones[20] = {6,5,4,3,2,1,11,12,13,14,32,33,34,35,53,54,55,57,58,59}; bool Visible [20];
Vector Bones_Pos[20];
Vector HeadPos = GetBoneWithRotation(mesh, 6);
Vector zb1 = HeadPos; zb1.Z += 0;
Vector zb2 = HeadPos; zb2.Z -= 0;
Vector fkzb1 = [self word2Screen:zb1 matrix:WordScreen]; Vector fkzb2 = [self word2Screen:zb2 matrix:WordScreen];
float height1 = fkzb2.Y - fkzb1.Y; float width1 = height1 / 2;

 // // // //
float originX1 = fkzb1.X - width1 / 2; float originY1 = fkzb1.Y;
//方框
CGRect rect = CGRectMake(originX1, originY1, width1, height1);
Vector aimpos = GetBoneWithRotation(mesh, Bones::Head); Vector aimxy = [self word2Screen:aimpos matrix:WordScreen];
Vector Pos[20]; Vector screenPos; Vector coordinatePos;
for (int i1 = 0; i1 < 20; i1++) {
Vector pos = GetBoneWithRotation(mesh, Bones[i1]);
Pos[i1] = pos;
Visible[i1] = LineTrace(objectpointer, pos, OwningActor, GWorld); Bones_Pos[i1] = [self word2Screen:pos matrix:WordScreen];
}
   
    
  
    
    
// 漏哪打哪
for (int i3 = 0; i3 < 20; i3++) {
if (Visible[i3] == true) {
screenPos = Bones_Pos[i3]; coordinatePos = Pos[i3]; break;
} }
     if(Dis==YES){
               //范围内敌人距离判断 来设定动态圈的大小。
               CGRect Dis = CGRectMake(kScreenWidth/2, kScreenHeight/2, 50, 50);
               BOOL Disif = CGRectContainsRect(Dis, rect);
           

                 if(Disif==YES){
                     
                     
                   if(tDistance > 0 && tDistance <= 50){
                       dongtaibanjin = 200 - tDistance +10;
                   }
                   if(tDistance >50 && tDistance<= 80){
                       dongtaibanjin = 170 - tDistance ;
                   }
                        if(tDistance >80 && tDistance<= 120){
                                         dongtaibanjin = 160 - tDistance ;
                                     }
                     if(tDistance >120 && tDistance <= 200){
                       dongtaibanjin = 15;
                   }
               }
           }
 
        if (CGRectContainsPoint(kAimRect, (CGPoint){screenPos.X, screenPos.Y})) {
    tDistance = CenterOffsetForVector(screenPos);
if (tDistance <= (RDistance+Radius) && tDistance < markDistance) {
markDistance = tDistance;
// 线连谁打谁, 画线的屏幕坐标 ---> markScreenPos.x / markScreenPos.y == 自己赋值过去绘画
    markScreenPos.x = screenPos.X;
    markScreenPos.y = screenPos.Y;
// 有找到符合射击范围的敌人, 在追踪那里判断 needAdjustAim 并执行追踪代码 needAdjustAim = true;
 needAdjustAim = true;
aimhead.x = coordinatePos.X;
    aimhead.y = coordinatePos.Y;
    aimhead.z = coordinatePos.Z;

//NSLog(@"*** name : mark / x: %f / y: %f", markScreenPos.x, markScreenPos.y);
} }

// if(Speak){
//
// }

lnfCJInfoModel *model = [[lnfCJInfoModel alloc] init]; model.number = Team;
model.name = name;
model.distance = getdis(mylnfo,HeadPos); model.rect = rect;
model.hp = xue; model.isAI = isAI; model.flag = 1;
lnfCJInfoBon *bon = [[lnfCJInfoBon alloc] init]; bon.Head = Bones_Pos[0];
bon.neck = Bones_Pos[1];
bon.spine_3 = Bones_Pos[2];
bon.spine_2 = Bones_Pos[3]; bon.spine_1 = Bones_Pos[4]; bon.pelvis = Bones_Pos[5]; bon.clavicle_r = Bones_Pos[6]; bon.upperarm_r = Bones_Pos[7]; bon.lowerarm_r = Bones_Pos[8]; bon.hand_r = Bones_Pos[9]; bon.clavicle_l = Bones_Pos[10]; bon.upperarm_l = Bones_Pos[11]; bon.lowerarm_l = Bones_Pos[12]; bon.hand_l = Bones_Pos[13]; bon.thigh_r = Bones_Pos[14]; bon.calf_r = Bones_Pos[15]; bon.foot_r = Bones_Pos[16]; bon.thigh_l = Bones_Pos[17]; bon.calf_l = Bones_Pos[18]; bon.foot_l = Bones_Pos[19]; model.bon = bon;
lnfCJisBon *isbone = [[lnfCJisBon alloc] init]; isbone.Head = Visible[0];
isbone.neck = Visible[1];
isbone.spine_3 = Visible[2];
isbone.spine_2 = Visible[3]; isbone.spine_1 = Visible[4]; isbone.pelvis = Visible[5]; isbone.clavicle_r = Visible[6]; isbone.upperarm_r = Visible[7]; isbone.lowerarm_r = Visible[8]; isbone.hand_r = Visible[9]; isbone.clavicle_l = Visible[10]; isbone.upperarm_l = Visible[11]; isbone.lowerarm_l = Visible[12]; isbone.hand_l = Visible[13]; isbone.thigh_r = Visible[14]; isbone.calf_r = Visible[15]; isbone.foot_r = Visible[16]; isbone.thigh_l = Visible[17]; isbone.calf_l = Visible[18]; isbone.foot_l = Visible[9]; model.isbon = isbone;
[infoArray addObject:model]; }
       //  CGRect rect1 = CGRectMake(Bones_Pos[i1].X, Bones_Pos[i1].Y,0 ,0 );
          
           }
                                      
    if (block) {
        block(infoArray,markScreenPos);
        }
    
}

void pre_aim(RegisterContext *rs, const HookEntryInfo *info);
void pre_aim(RegisterContext *rs, const HookEntryInfo *info)
{
    if (needAdjustAim) {
        
        rs->floating.q[0].f.f1 = aimhead.x;
        rs->floating.q[1].f.f1 = aimhead.y;
        rs->floating.q[2].f.f1 = aimhead.z;
    }
    
}
static float (*orig_lnstanthit)(int64_t a1, float32x4_t *a2, int64_t a3, int64_t a4, float result);
static float function_lnstanthit(int64_t a1, float32x4_t *a2, int64_t a3, int64_t a4, float result)
{
    float speed = result;

    if (speed == 91000.00000f ||   //AWM
        speed == 16000.00000f ||   //十字努
        speed == 84000.00000f ||   //SLR射手步枪
        speed == 76000.00000f ||   //98K
        speed == 76000.00000f ||   //Win94狙击抢
        speed == 79000.00000f ||   //M24狙击枪
        speed == 85300.00000f ||   //MK14狙击枪
        speed == 99000.00000f ||   //Mini14射手步枪
        speed == 80000.00000f      //SKS狙击枪
        )
    {
        result = shunji;
    }
    else if (
             speed == 71500.00000f ||    //AK
             speed == 71500.00000f ||    //R1895
             speed == 71500.00000f ||    //狗杂
             speed == 71500.00000f ||    //DP轻机枪
             speed == 94500.00000f ||    //QBU射手步枪
             speed == 87000.00000f ||    //QBZ突击步枪
             speed == 94000.00000f ||    //QUG突击步枪
             speed == 91500.00000f ||    //M249轻机枪
             speed == 88000.00000f ||    //M416突击步枪
             speed == 90000.00000f ||    //M16A4突击步枪
             speed == 87000.00000f ||    //SCAR-L突击步枪
             speed == 68000.00000f       //M762突击步枪
             )
    {
        result = shunji;
    }
    else if (
             speed == 36000.00000f ||    //S1987散弹枪
             speed == 37000.00000f ||    //S686散弹枪
             speed == 35000.00000f ||    //S12K散弹枪
             speed == 33000.00000f ||    //短管散弹枪
             speed == 33000.00000f ||    //VSS射手步枪
             speed == 40000.00000f ||    //UMP9冲锋枪
             speed == 35000.00000f ||    //UZI冲锋枪
             speed == 37500.00000f ||    //P18C冲锋枪
             speed == 38000.00000f ||    //P92冲锋枪
             speed == 28000.00000f ||    //汤姆逊冲锋枪
             speed == 30000.00000f ||    //Vector冲锋枪
             speed == 30000.00000f ||    //R45手枪
             speed == 25000.00000f ||    //P1911手枪)
             speed == 33000.00000f       //R1895手枪
             )
    {
        result =shunji;
    }

    float ret = orig_lnstanthit(a1, a2, a3, a4, result);
    return ret;
}
void fw_handler(RegisterContext *rs, const HookEntryInfo *info);
void fw_handler(RegisterContext *rs, const HookEntryInfo *info){
    if((*(float*)(rs->general.regs.x20+0x90)) == 28){
        *(float*)(rs->general.regs.x20+0x90) = fwdaxiao;
       
    }
}
+ (void)load
{
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(40* NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    // 追踪//
DobbyInstrument((void *)((unsigned long)_dyld_get_image_vmaddr_slide(0) + 0x1041F0F24), pre_aim);
      //瞬击E9F08
       DobbyHook((void *)((unsigned long)_dyld_get_image_vmaddr_slide(0) + 0x1041E96F8), (void *)function_lnstanthit, (void **)&orig_lnstanthit);
        //范围
           unsigned long fw = (_dyld_get_image_vmaddr_slide(0) + 0x105ED7CA4);
            DobbyInstrument((void *)fw, fw_handler);

    });
}
@end
