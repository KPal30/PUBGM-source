//
//  JHCJDrawDataFactory.h
//  JHCJDraw
//
//  Created by 佚名 on 2021/1/8.
//

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>

#define kAimRadius     100

NS_ASSUME_NONNULL_BEGIN

typedef void (^JHCJDrawDataFactoryaFetchDataBlock)(NSArray *infoArray, CGPoint aimPoint);

@interface JHCJDrawDataFactorya : NSObject

+ (instancetype)factory;
- (void)fetchData:(JHCJDrawDataFactoryaFetchDataBlock)block;
@end

NS_ASSUME_NONNULL_END
