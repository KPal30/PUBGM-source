//
//  YMCJInfoModel.m
//  Test
//
//  Created by yiming on 2021/5/19.
//  Copyright © 2021 lengfeng. All rights reserved.
//

#import "YMCJInfoModel.h"

@implementation lnfCJisBon

@end

@implementation lnfCJInfoBon

@end

@implementation lnfCJInfoModel

+ (NSString *)getName:(const UTF16*)sourceStart t:(UTF8*)targetStart l:(size_t)outLen f:(ConversionFlags)flags
{
    Utf16_To_Utf8(sourceStart, targetStart, outLen, strictConversion);
    NSString *name = [NSString stringWithUTF8String:(const char *)targetStart];
    return name;
}

@end
