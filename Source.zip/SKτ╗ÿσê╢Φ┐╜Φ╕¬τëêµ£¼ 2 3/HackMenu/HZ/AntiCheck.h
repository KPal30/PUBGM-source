//
//  Patchoffset.h
//  Hookcc
//
//  Created by 李良林 on 2020/8/29.
//

#import <Foundation/Foundation.h>
#import <mach/mach.h>
#import <mach/mach_traps.h>
#include <mach-o/dyld.h>

mach_port_t port;

bool has_aslr()
{
    return (_dyld_get_image_header(0)->flags & MH_PIE);
}

vm_address_t get_slide()
{
    return _dyld_get_image_vmaddr_slide(0);
}

template<typename T> void private_write_mem(vm_address_t addr, T data, int size = 0)
{
    if(size == 0)
        size = sizeof(T);
    if(!port)
        port = mach_task_self();
    
    vm_protect(port, (vm_address_t) addr, size, NO,VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
    
    vm_write(port, addr, (vm_address_t)&data, size);
    
    vm_protect(port, (vm_address_t)addr, size, NO,VM_PROT_READ | VM_PROT_EXECUTE);
}

template<typename T> T read_mem(vm_address_t addr)
{
    if(!port)
        port = mach_task_self();
    T data_to_return;

    vm_protect(port, (vm_address_t) addr, sizeof(T), NO,VM_PROT_READ | VM_PROT_WRITE | VM_PROT_COPY);
    
    mach_msg_type_number_t count;
    vm_read(port, addr, sizeof(T), (vm_address_t*)&data_to_return, &count);

    vm_protect(port, (vm_address_t)addr, sizeof(T), NO,VM_PROT_READ | VM_PROT_EXECUTE);

    return data_to_return;
}
