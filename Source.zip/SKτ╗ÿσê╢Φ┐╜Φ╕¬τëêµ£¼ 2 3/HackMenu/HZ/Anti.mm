//
//
////  Created by 李良林 on 2020/11/17.
////  Copyright © 2020 李良林. All rights reserved.
//
//
//#import "Anti.h"
//#import <dlfcn.h>
//#import <mach-o/dyld.h>
//#import "AntiCheck.h"
//
//
//@implementation private_VMPatchOffsetTool
//
//+ (void)load
//{
//    [[SwiftLoad shared] swiftLoad];
//    port = mach_task_self();
//
//    //__dyld_
// 
//   private_write_mem<int>(get_slide() + 0x10211E230, CFSwapInt32(0xC0035FD6));
//    private_write_mem<int>(get_slide() + 0x10211E200, CFSwapInt32(0xC0035FD6));
//
//}
//
//@end
//
