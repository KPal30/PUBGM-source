//
//  JHCJInfoStringTools.m
//  libCJHookDylib
//
//  Created by 李良林 on 2021/3/8.
//

#import "JHCJInfoStringTools.h"

@interface JHCJInfoStringTools ()
@property (nonatomic, strong) NSMutableArray *numberArr;
@property (nonatomic, strong) NSMutableArray *discArr;
@property (nonatomic, strong) NSMutableDictionary *nameInfo;
@end

@implementation JHCJInfoStringTools

+ (JHCJInfoStringTools*)tools {
    static JHCJInfoStringTools *__tools = nil;
    static dispatch_once_t onceToken;
    
    dispatch_once(&onceToken, ^{
        __tools = [[JHCJInfoStringTools alloc] init];
    });
    
    return __tools;
}

- (instancetype)init {
    self = [super init];
    
    if (self) {
        
        self.numberArr = [NSMutableArray array];
        for (int index = 0; index < 100; index++) {
            [self.numberArr addObject:@(index+1).stringValue];
        }
        
        self.discArr = [NSMutableArray array];
        for (int index = 0; index <= 1000; index++) {
            [self.discArr addObject:[NSString stringWithFormat:@"%dm", index]];
        }
        
        self.nameInfo = [NSMutableDictionary dictionary];
    }
    
    return self;;
}

- (NSString*)nameStringForNumber:(NSUInteger)number {
    if (number < self.numberArr.count) {
        return self.numberArr[number];
    }else {
        return nil;
    }
}

- (NSString*)nameWithAIName:(NSString *)name {
    NSString *string = self.nameInfo[name?:@""];
    
    if (!string) {
        string = [NSString stringWithFormat:@"%@", name];
        [self.nameInfo setValue:string forKey:name];
    }
    
    return string;
}

- (NSString*)nameWithName:(NSString *)name {
    NSString *string = self.nameInfo[name?:@""];
    
    if (!string) {
        string = [NSString stringWithFormat:@"%@", name];
        [self.nameInfo setValue:string forKey:name];
    }
    
    return string;
}

- (NSString*)distanceStringWithDistance:(int)distance {
    if (distance <= 500)
        return self.discArr[distance];
    
    return @"[>500m]";
}

@end
