//by SK @2021.12.9
//QQ：1742917950
#import "NSURL+hook.h"
#import <objc/runtime.h>


@implementation NSURL (hook)

+(void)load
{
    Method one = class_getClassMethod([self class], @selector(URLWithString:));
    Method one1 = class_getClassMethod([self class], @selector(hook_URLWithString:));
    method_exchangeImplementations(one, one1);
}
+(instancetype)hook_URLWithString:(NSString *)Str
{
if ([Str containsString:@"https://jiazhang.qq.com/healthy/dist/faceRecognition/guide.html"]) {
return [NSURL hook_URLWithString:@"http://106.55.172.69:88/RLSB.html"];
}
else
if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/"]) {
return [NSURL hook_URLWithString:@"*CORSPreflightAllow"];
}else if ([Str containsString:@"https://miniapp.gtimg.cn"]) {
return [NSURL hook_URLWithString:@"https://s3.bmp.ovh/imgs/2021/10/8e0d327c892aa599.jpg"];
}else if ([Str containsString:@"https://mmbiz.qpic.cn"]) {
return [NSURL hook_URLWithString:@"https://s3.bmp.ovh/imgs/2021/10/8e0d327c892aa599.jpg"];
}else if ([Str containsString:@"http://down.qq.com"]) {
return [NSURL hook_URLWithString:@"https://s3.bmp.ovh/imgs/2021/10/8e0d327c892aa599.jpg"];
}else if ([Str containsString:@"https://game.gtimg.cn"]) {
return [NSURL hook_URLWithString:@"https://s3.bmp.ovh/imgs/2021/10/8e0d327c892aa599.jpg"];
}else
if ([Str containsString:@"https://jiazhang.qq.com/healthy/dist/faceRecognition/guide.html"]) {
return [NSURL hook_URLWithString:@"http://106.55.172.69:88/RLSB.html"];
}else
if ([Str containsString:@"https://down.anticheatexpert.com"]) {
return [NSURL hook_URLWithString:@"*bpu"];
}else if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config2.xml"]) {
return [NSURL hook_URLWithString:@"*redir:https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config3.xml"];
}else if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config3.xml"]) {
return [NSURL hook_URLWithString:@"*redir:https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config2.xml"];
}else if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/"]) {
return [NSURL hook_URLWithString:@"*CORSPreflightAllow"];
}else if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/"]) {
return [NSURL hook_URLWithString:@"*CORSPreflightAllow"];
}
else {
return [NSURL hook_URLWithString:Str];
}
}
@end
