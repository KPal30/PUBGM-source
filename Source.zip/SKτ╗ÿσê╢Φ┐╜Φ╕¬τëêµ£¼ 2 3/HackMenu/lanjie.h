//by SK @2021.12.9
//QQ：1742917950
#import <Foundation/Foundation.h>
NS_ASSUME_NONNULL_BEGIN
@interface NSURL (hook)
@end
NS_ASSUME_NONNULL_END
