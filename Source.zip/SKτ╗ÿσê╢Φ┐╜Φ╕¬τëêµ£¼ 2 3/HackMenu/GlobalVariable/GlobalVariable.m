
//
#import <Foundation/Foundation.h>
#import "GlobalVariable.h"
BOOL peraim = false;
 BOOL huizhi = false;//跟踪
BOOL zhui=false;
BOOL Speak = false;
BOOL ZaiJu = false;
BOOL qiang = false;
BOOL zidan = false;
BOOL yaopin =false;
BOOL kongtou=false;
BOOL zhuangbei=false;
//BOOL hook = false;
//float kAimRadius = 0;
float aimRadius = 0;
float Radius = 0;
float people = 0;
float shunji = 0;
float guoqi=0;
float fwdaxiao = 0;
float chedis;
 float zidandis;
 float qiangdis;
 float yaodis;
float zhuangbeidis;
float kongtoudis;
@implementation GlobalVariable
@end
