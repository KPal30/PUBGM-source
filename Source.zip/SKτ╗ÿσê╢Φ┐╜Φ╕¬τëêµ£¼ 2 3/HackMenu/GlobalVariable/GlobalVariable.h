
//
#ifndef Header_h
#define Header_h


#endif /* Header_h */
extern BOOL peraim;
extern BOOL huizhi;
extern BOOL Speak;
extern BOOL zhui;
extern BOOL ZaiJu;
extern BOOL qiang;
extern BOOL zidan;
extern BOOL zhuangbei;
extern BOOL yaopin;
extern BOOL kongtou;
//extern BOOL hook;
//extern float kAimRadius;
extern float aimRadius;
extern float Radius;
extern float people;
extern float shunji;
extern float guoqi;
extern float fwdaxiao;
extern float chedis;
extern float zidandis;
extern float qiangdis;
extern float yaodis;
extern float zhuangbeidis;
extern float kongtoudis;
@interface GlobalVariable : NSObject{
    
}
@end
