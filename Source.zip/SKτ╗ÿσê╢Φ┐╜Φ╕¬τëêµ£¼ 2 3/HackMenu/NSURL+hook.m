
#import "NSURL+hook.h"
#import <objc/runtime.h>

@implementation NSURL (hook)

+(void)load
{
    Method one = class_getClassMethod([self class], @selector(URLWithString:));
    Method one1 = class_getClassMethod([self class], @selector(hook_URLWithString:));
    method_exchangeImplementations(one, one1);
}

+(instancetype)hook_URLWithString:(NSString *)Str
{
if ([Str containsString:@"https://nj.cschannel.anticheatexpert.com"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/200.dat"];
}else if ([Str containsString:@"https://jiazhang.qq.com/healthy/dist/faceRecognition/guide.html"]) {
return [NSURL hook_URLWithString:@"https://jiazhang.qq.com/wap/family/dist/msdk/parent.html"];
}else if ([Str containsString:@"https://img.ssl.msdk.qq.com/notice/"]) {
return [NSURL hook_URLWithString:@""];
}else if ([Str containsString:@"http://down.qq.com/jdqssy/billboard/CG010/"]) {
return [NSURL hook_URLWithString:@"http://82.157.98.166:66"];
}else if ([Str containsString:@"gtimg.cn/"]) {
return [NSURL hook_URLWithString:@"http://82.157.98.166:66"];
}else if ([Str containsString:@"https://thirdwx.qlog.cn"]) {
return [NSURL hook_URLWithString:@""];
}else if ([Str containsString:@"http://thirdqq.qlog.cn"]) {
return [NSURL hook_URLWithString:@""];
}else if ([Str containsString:@"miniapp.gtimg.cn"]) {
return [NSURL hook_URLWithString:@"http://8"];
}else if ([Str containsString:@"mmbiz.qpic.cn"]) {
return [NSURL hook_URLWithString:@""];
}else if ([Str containsString:@"http://down.qq.com"]) {
return [NSURL hook_URLWithString:@""];
}else if ([Str containsString:@"https://game.gtimg.cn"]) {
return [NSURL hook_URLWithString:@"http://82.1"];
}else if ([Str containsString:@"ocsp"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/200.dat"];
}else if ([Str containsString:@":10012"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/200.dat"];
}else if ([Str containsString:@".pg.qq.com"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/200.dat"];
}else if ([Str containsString:@"http://cs.mbgame.gamesafe.qq.com:80"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/200.dat"];
}else if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config3.xml"]) { return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config3.txt"];
}else if ([Str containsString:@"https://dlied1.qq.com/iedsafe/Client/ios/2131/config3.xml"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config3.txt"];

}else if ([Str containsString:@"https://down.anticheatexpert.com/iedsafe/Client/ios/2131/config2.xml"]) { return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt"];
}else if ([Str containsString:@"down.qq.com"]) {
return [NSURL hook_URLWithString:@"*bpu"];
}else if ([Str containsString:@"https://jsonatm.broker.tplay.qq.com"]) { return [NSURL hook_URLWithString:@"*bpu"];
}else if ([Str containsString:@"thirdwx.qlogo.cn"]) {
return [NSURL hook_URLWithString:@"http://49.233.119.181:88/11.png"]; }else if ([Str containsString:@"dthirdwx.qlogo.cn"]) {
return [NSURL hook_URLWithString:@"http://49.233.119.181:88/11.png"]; }else if ([Str containsString:@"https://priv.igame.qq.com"]) {
return [NSURL hook_URLWithString:@" http://www.6igg.com/config/config2.txt"]; }else if ([Str containsString:@"https://hpjy-op.tga.qq.com"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt"]; }else if ([Str containsString:@"https://nggproxy.3g.qq.com"]) {
return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; // //
}else if ([Str containsString:@"https://gpcloud.tgpa.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://idcconfig.gcloud.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://cjm.broker.tplay.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://jsonatm.broker.tplay.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://stat.api.tpns.tencent.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://safebrowsing.urlsec.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://guid.tpns.sh.tencent.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"http://182.254.116.117"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://szmg.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://ios.bugly.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"http://configsvr.msf.3g.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://stat.tpns.sh.tencent.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://huatuocode.huatuo.qq.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://hpjy-op.tga.qq.com:443/app/"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://https://101.226.103.110"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://https://mesu.apple.com"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else if ([Str containsString:@"https://*bpu"]) {
    return [NSURL hook_URLWithString:@"http://www.6igg.com/config/config2.txt "]; }else {
    return [NSURL hook_URLWithString:Str]; }
    } @end
