//#import <CoreText/CoreText.h>
//#import "MBProgressHUD.h"
//#import <Foundation/Foundation.h>
//#import <UIKit/UIKit.h>
//#import <UIKit/UIAlertView.h>
//#import <UIKit/UIControl.h>
//#import <AVFoundation/AVFoundation.h>
//#import "PubgLoad.h"
//#import <UIKit/UIKit.h>
//#import "JHPP.h"
//#import "JHDragView.h"
//#import"HeeeNoScreenShotView.h"
//#import "metalbiew.h"
//#import <AFNetworkReachabilityManager.h>
//#define kWidth  [UIScreen mainScreen].bounds.size.width
//#define kHeight [UIScreen mainScreen].bounds.size.height
//#define kScale [UIScreen mainScreen].scale
//#import "DLGMemEntry.h"
//#import <AVFoundation/AVFoundation.h>
//#import <AdSupport/ASIdentifierManager.h>
//#import "defines.h"
//#import "MF_Base64Additions.h"
//#import "NSDictionary+StichingStringkeyValue.h"
//#import "NSString+MD5.h"
//#import "NSString+URLCode.h"
//#import "UserInfoManager.h"
//#import "Config.h"
//#import "DES3Utill.h"
//#import "UIAlertView+Blocks.h"
//#import "SCLAlertView.h"
//#import "copyright.h"
//#define kTest   0
//#define g 0.86602540378444
//#define kWidth  [UIScreen mainScreen].bounds.size.width
//#define kHeight [UIScreen mainScreen].bounds.size.height
//@interface VerifyEntry ()<UIAlertViewDelegate>
//@end
//@implementation DLGMemEntry
////配置
//static void __attribute__((constructor)) entry()
//{ if([[[NSBundle mainBundle] bundleIdentifier] isEqualToString:@""]) {
//    // [NSObject VPNtishitiao];//检测vpn代理 注释关闭
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        [NSObject FXMS];
//        if([NSObject FXMS]){
//            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
//                           {           NSString * TXT = NULL;
//                //TXT  = [DES3Utill decrypt:LD_TXT gkey:LD_AAAA];//盗版说明
//                
//                NSString * SQURL = NULL;
//                //  SQURL  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];//默认客户bsurl
//                NSRange name1 = [SQURL rangeOfString:@"://"];
//                NSRange name2 = [SQURL rangeOfString:@"/AppEn.php"];
//                NSRange name = NSMakeRange(name1.location + name1.length, name2.location - name1.location - name1.length);
//                NSString *member = [SQURL substringWithRange:name];
//                NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@".:"];
//                NSString *newmember = [member stringByTrimmingCharactersInSet:set];
//                
//                
//                NSString * SQTITLE = NULL;
//                // SQTITLE  = [DES3Utill decrypt:LD_SQTITLE gkey:LD_AAAA];
//                NSString * LTURL = NULL;
//                //  LTURL  = [DES3Utill decrypt:LD_LTURL gkey:LD_AAAA];//
//                
//                NSString *requestStr =[[NSString alloc]initWithFormat:@"%@%@%@",LTURL,@"html/",newmember];
//                NSString *htmlStr = [NSString stringWithContentsOfURL:[NSURL URLWithString:requestStr] encoding:NSUTF8StringEncoding error:nil];
//                if ([htmlStr rangeOfString:@"NULL"].location == NSNotFound)
//                {
//                    NSLog(@"检测网络正常");
//                    
//                }
//                else
//                {
//                    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//                    alert.backgroundType = SCLAlertViewBackgroundBlur;
//                    [alert addTimerToButtonIndex:0 reverse:YES];//yes为倒计时NO为正数
//                    
//                    [alert addButton:SQTITLE actionBlock:^
//                     {
//                        
//                        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:LTURL]];
//                        exit(0);
//                        
//                    }];
//                    [alert showNotice:SQTITLE subTitle:TXT closeButtonTitle:nil duration:5.0f];
//                }
//                
//            });}
//    });
//    
//}
//}
//
//@end
//
//@implementation VerifyEntry
//- (BOOL)FXMS{
//    //1.创建网络状态监测管理者
//    AFNetworkReachabilityManager *manger = [AFNetworkReachabilityManager sharedManager];
//    //开启监听，记得开启，不然不走block
//    [manger startMonitoring];
//    //2.监听改变
//    [manger setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
//        
//        //AFNetworkReachabilityStatusUnknown          = -1,
//        //AFNetworkReachabilityStatusNotReachable     = 0,
//        //AFNetworkReachabilityStatusReachableViaWWAN = 1,
//        2;          //AFNetworkReachabilityStatusReachableViaWiFi = 2,
//        
//        switch (status) {
//            case AFNetworkReachabilityStatusUnknown:
//                NSLog(@"未知");
//                break;
//            case AFNetworkReachabilityStatusNotReachable:
//                NSLog(@"没有网络");
//                break;
//            case AFNetworkReachabilityStatusReachableViaWWAN:
//                NSLog(@"3G|4G");
//                break;
//            case AFNetworkReachabilityStatusReachableViaWiFi:
//                NSLog(@"WiFi");
//                break;
//            default:
//                break;
//        }
//    }];
//    
//    
//    
//}
//
//+ (instancetype)MySharedInstance
//{
//    static VerifyEntry *sharedSingleton;
//    
//    if (!sharedSingleton)
//    {
//        static dispatch_once_t oncePPM;
//        dispatch_once(&oncePPM, ^
//                      {
//            sharedSingleton = [[VerifyEntry alloc] init];
//        });
//    }
//    
//    return sharedSingleton;
//}
//
//
//- (NSString*)getIDFA
//{
//    ASIdentifierManager *as = [ASIdentifierManager sharedManager];
//    return as.advertisingIdentifier.UUIDString;
//}
//
//- (void)showAlertMsg:(NSString *)show error:(BOOL)error
//{
//    DisPatchGetMainQueueBegin();
//    
//    NSString *title = @"";
//    if (YES == error)
//    {
//        title = @"信息";
//    }
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:show delegate:nil cancelButtonTitle:@"好" otherButtonTitles:nil, nil];
//    [alert show];
//    
//    DisPatchGetMainQueueEnd();
//}
//
//- (void)startProcessActivateProcess:(NSString *)code finish:(void (^)(NSDictionary *done))finish
//{
//    NSString * strmutualkey = NULL;
//    strmutualkey  = [DES3Utill decrypt:LD_KEY gkey:LD_AAAA];
//    NSString * strhost = NULL;
//    strhost  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];
//    //授权码验证
//    NSMutableDictionary *param = [NSMutableDictionary dictionary];
//    param[@"api"] = @"login.ic";
//    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
//    [dateFormatter setDateFormat:@"yyyy-MM-dd#HH:mm:ss"];
//    NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
//    param[@"BSphpSeSsL"] = [dateStr MD5Digest];
//    NSDate *date = [NSDate date];
//    NSTimeZone * zone = [NSTimeZone systemTimeZone];
//    NSInteger interval = [zone secondsFromGMTForDate:date];
//    NSDate * nowDate = [date dateByAddingTimeInterval:interval];
//    NSString *nowDateStr = [[nowDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
//    param[@"date"] = nowDateStr;
// //   param[@"md5"] = [DES3Utill decrypt:LD_MD5 gkey:LD_AAAA];
//    param[@"mutualkey"] = strmutualkey;
//    param[@"icid"] = code;
//    param[@"icpwd"] = @"";
//    param[@"key"] = [self getIDFA];
//    param[@"maxoror"] = [self getIDFA];
//    [NetTool Post_AppendURL:strhost myparameters:param mysuccess:^(id responseObject)
//     {
//        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//        if (dict)
//        {
//            NSString *dataString = dict[@"response"][@"data"];
//            NSRange range = [dataString rangeOfString:@"|1081|"];
//            
//            if (strstr(dataString.UTF8String,"|1081|"))
//            {
//                NSString *activationDID = [[NSUserDefaults standardUserDefaults]objectForKey:@"activationDeviceID"];
//                if (![activationDID isEqualToString:code])
//                {
//                    [[NSUserDefaults standardUserDefaults] setObject:code forKey:@"activationDeviceID"];
//                }
//                
//                UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
//                NSArray *arr = [dataString componentsSeparatedByString:@"|"];
//                if (arr.count >= 6)
//                {
//                    manager.state01 = arr[0];
//                    manager.state1081 = arr[1];
//                    manager.deviceID = arr[2];
//                    manager.returnData = arr[3];
//                    manager.expirationTime = arr[4];
//                    manager.activationTime = arr[5];
//                    if(manager.deviceID!=[self getIDFA]){
//                        manager.state01 = nil;
//                        manager.state1081 = nil;
//                        manager.deviceID = nil;
//                        manager.returnData = nil;
//                        manager.expirationTime = nil;
//                        manager.activationTime = nil;
//                        [self processActivate];
//                    }else{
//                    }
//                    NSString* bbbbbb=[NSString stringWithFormat:@" %@", arr[4]];
//                    if ([bbbbbb containsString:@"null"]) {
//                        
//                        NSLog(@"过期时间 包含 null被破解闪退");
//                        exit(0);
//                    }
//                    if (bbbbbb.length<5) {
//                        exit(0);
//                        
//                        NSLog(@"过期时间长度小于5 闪退");
//                        exit(0);
//                    }else {
//                        
//                        NSLog(@"正常放行");
//                        DisPatchGetMainQueueBegin();
//                        NSString *showMsg = [NSString stringWithFormat:@"过期时间: %@", arr[4]];
//                        [UIAlertView showWithTitle:@"提示:激活成功重启应用生效" message:showMsg cancelButtonTitle:@"确定" otherButtonTitles:nil tapBlock:nil];
//                        DisPatchGetMainQueueEnd();
//
//                    }
//                    
//                    
//                }
//            }
//            else
//            {
//                NSString *messageStr = dict[@"response"][@"data"];
//                UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
//                manager.state01 = nil;
//                manager.state1081 = nil;
//                manager.deviceID = nil;
//                manager.returnData = nil;
//                manager.expirationTime = nil;
//                manager.activationTime = nil;
//                [self showAlertMsg:messageStr error:YES];
//                [self processActivate];
//                
//            }
//        }
//    } myfailure:^(NSError *error)
//     {
//        [self processActivate];
//    }];
//    
//}
//
//- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
//{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        {
//         
//            NSString *CONFIRM = @"激活";
//            
//            NSString *btnTitle = [alertView buttonTitleAtIndex:buttonIndex];
//            if (YES == [btnTitle isEqualToString:CONFIRM])
//            {
//                UITextField *tf = [alertView textFieldAtIndex:0];
//                if (nil == tf.text || 0 == tf.text.length)
//                {
//                    [self processActivate];
//                    return ;
//                }
//                
//                [self startProcessActivateProcess:tf.text finish:nil];
//            }
//            else
//            {
//                [self processActivate];
//            }
//        
//        }
//    });
//    
//}
//- (void)processActivate
//{
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
//                   {
//    
//        NSString *CONFIRM = @"激活";
//        
//        NSString *CANCEL = @"退出";
//        
//        
//        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"温馨提示:请在此输入激活码" delegate:self cancelButtonTitle:CANCEL otherButtonTitles:CONFIRM, nil];
//        
//        
//        
//        
//        [alert setAlertViewStyle:UIAlertViewStylePlainTextInput];
//        UITextField *txtName = [alert textFieldAtIndex:0];
//        txtName.placeholder = @"";
//        [alert show];
//        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(30 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//            exit(0);});
//        
//    });
//    
//}
//@end
//
//@interface iosgods : NSObject
//
//@end
//
//
//
//@implementation NSObject (hook)
//
////直接给予闪退
//
////公告
//
//
//- (BOOL)FXMS{
//    NSString *requestStr = @"http://42.51.55.138:88/";
//    NSString *htmlStr = [NSString stringWithContentsOfURL:[NSURL URLWithString:requestStr] encoding:NSUTF8StringEncoding error:nil];
//    
//    if ([htmlStr rangeOfString:@"NULL"].location == NSNotFound)
//    {
//        NSLog(@"检测网络正常");
//        return YES;
//    }
//    else
//    {
//        //你的代理太强 全部显示断网闪退，我全部注释了{}之间的代码
//        //                                   SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//        //                                   alert.backgroundType = SCLAlertViewBackgroundBlur;
//        //                                   [alert addTimerToButtonIndex:0 reverse:YES];//yes为倒计时NO为正数
//        //                                   dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//        //                                         exit(0);
//        //                                   });
//        //
//        //                                   [alert addButton:@"确定" actionBlock:^
//        //                                   {
//        //
//        //                                       exit(0);
//        //                                   }];
//        //                                   [alert showNotice:@"温馨提示" subTitle:@"网络连接失败" closeButtonTitle:nil duration:5];
//    }
//    
//    
//    
//    
//}
//- (BOOL)ZZ{
//    
//    NSString * TXT = NULL;
//    TXT  = [DES3Utill decrypt:LD_TXT gkey:LD_AAAA];
//    
//    NSString * SQURL = NULL;
//    SQURL  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];//默认客户bsurl
//    NSRange name1 = [SQURL rangeOfString:@"://"];
//    NSRange name2 = [SQURL rangeOfString:@"/AppEn.php"];
//    NSRange name = NSMakeRange(name1.location + name1.length, name2.location - name1.location - name1.length);
//    NSString *member = [SQURL substringWithRange:name];
//    
//    
//    
//    NSString * SQTITLE = NULL;
//    SQTITLE  = [DES3Utill decrypt:LD_SQTITLE gkey:LD_AAAA];
//    NSString * LTURL = NULL;
//    LTURL  = [DES3Utill decrypt:LD_LTURL gkey:LD_AAAA];
//    NSString *str1 = [member substringToIndex:8];
//    NSString *requestStr =[[NSString alloc]initWithFormat:@"%@%@%@",LTURL,@"html/",str1];
//    NSString *htmlStr = [NSString stringWithContentsOfURL:[NSURL URLWithString:requestStr] encoding:NSUTF8StringEncoding error:nil];
//    if ([htmlStr rangeOfString:@"NULL"].location == NSNotFound)
//    {
//        NSLog(@"检测网络正常");
//        return NO;
//    }
//    else
//    {
//        SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//        alert.backgroundType = SCLAlertViewBackgroundBlur;
//        [alert addTimerToButtonIndex:0 reverse:YES];//yes为倒计时NO为正数
//        
//        [alert addButton:SQTITLE actionBlock:^
//         {
//            
//            [[UIApplication sharedApplication] openURL:[NSURL URLWithString:LTURL]];
//            exit(0);
//            
//        }];
//        [alert showNotice:SQTITLE subTitle:TXT closeButtonTitle:nil duration:5.0f];
//    };
//    
//}
//#pragma mark  提示条
//-(void)showMessage:(NSString *)message duration:(NSTimeInterval)time
//{
//    CGSize screenSize = [[UIScreen mainScreen] bounds].size;
//    
//    UIWindow * window = [UIApplication sharedApplication].keyWindow;
//    UIView *showview =  [[UIView alloc]init];
//    showview.backgroundColor = [UIColor blueColor];
//    showview.frame = CGRectMake(1, 1, 1, 1);
//    showview.alpha = 1.0f;
//    showview.layer.cornerRadius = 5.0f;
//    showview.layer.masksToBounds = YES;
//    [window addSubview:showview];
//    
//    UILabel *label = [[UILabel alloc]init];
//    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
//    paragraphStyle.lineBreakMode = NSLineBreakByWordWrapping;
//    
//    NSDictionary *attributes = @{NSFontAttributeName:[UIFont systemFontOfSize:15.f],
//                                 NSParagraphStyleAttributeName:paragraphStyle.copy};
//    
//    CGSize labelSize = [message boundingRectWithSize:CGSizeMake(207, 999)
//                                             options:NSStringDrawingUsesLineFragmentOrigin
//                                          attributes:attributes context:nil].size;
//    
//    label.frame = CGRectMake(10, 5, labelSize.width +20, labelSize.height);
//    label.text = message;
//    label.textColor = [UIColor redColor];
//    //label.textAlignment = 1;
//    label.backgroundColor = [UIColor blueColor];
//    label.font = [UIFont boldSystemFontOfSize:15];
//    [showview addSubview:label];
//    
//    showview.frame = CGRectMake((screenSize.width - labelSize.width - 20)/2,
//                                screenSize.height - 300,
//                                labelSize.width+40,
//                                labelSize.height+10);
//    [UIView animateWithDuration:time animations:^{
//        showview.alpha = 0;
//    } completion:^(BOOL finished) {
//        [showview removeFromSuperview];
//    }];
//}
//@end
//
//@interface PubgLoad()
//@property (nonatomic, strong) metalbiew *vna;
//@end
//
//@implementation PubgLoad
//
//static PubgLoad *extraInfo;
//static BOOL MenDeal;
//static time_t (*orig_time)(void);
//
//
//
//
//
//
//
//
//
//
//
////123
////填写功能头文件
//
//#pragma mark -------------------------------------视图-------------------------------------------
//
//+ (void)load
//{
//    
//    
//    //uuu
//    NSString * strmutualkey = NULL;
//    strmutualkey  = [DES3Utill decrypt:LD_KEY gkey:LD_AAAA];
//    NSString * strhost = NULL;
//    strhost  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];
//    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
//                   {
//        
//        if([[NSUserDefaults standardUserDefaults] objectForKey:@"activationDeviceID"] != nil)
//        {
//            NSMutableDictionary *param = [NSMutableDictionary dictionary];
//            param[@"api"] = @"login.ic";
//            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
//            [dateFormatter setDateFormat:@"yyyy-MM-dd#HH:mm:ss"];
//            NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
//            param[@"BSphpSeSsL"] = [dateStr MD5Digest];
//            NSDate *date = [NSDate date];
//            NSTimeZone * zone = [NSTimeZone systemTimeZone];
//            NSInteger interval = [zone secondsFromGMTForDate:date];
//            NSDate * nowDate = [date dateByAddingTimeInterval:interval];
//            NSString *nowDateStr = [[nowDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
//            param[@"date"] = nowDateStr;
//         //   param[@"md5"] = [DES3Utill decrypt:LD_MD5 gkey:LD_AAAA];
//            param[@"mutualkey"] = strmutualkey;
//            param[@"icid"] = [[NSUserDefaults standardUserDefaults] objectForKey:@"activationDeviceID"];
//            param[@"icpwd"] = @"";
//            param[@"key"] = [[VerifyEntry MySharedInstance] getIDFA];
//            param[@"maxoror"] = [[VerifyEntry MySharedInstance] getIDFA];
//            [NetTool Post_AppendURL:strhost myparameters:param mysuccess:^(id responseObject)
//             {
//                NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject
//                                                                     options:NSJSONReadingMutableContainers
//                                                                       error:nil];
//                if (dict)
//                {
//                    NSString *dataString = dict[@"response"][@"data"];
//                    NSRange range = [dataString rangeOfString:@"|1081|"];
//                    
//                    
//                    if (strstr(dataString.UTF8String,"|1081|"))
//                    {
//                        UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
//                        NSArray *arr = [dataString componentsSeparatedByString:@"|"];
//                        
//                        
//                        {
//                            manager.state01 = arr[0];
//                            manager.state1081 = arr[1];
//                            manager.deviceID = arr[2];
//                            manager.returnData = arr[3];
//                            manager.expirationTime = arr[4];
//                            manager.activationTime = arr[5];
//                            if([arr[4] rangeOfString:@":"].location !=NSNotFound)//_roaldSearchText
//                            {
//                                
//                                if(manager.deviceID != [[VerifyEntry MySharedInstance] getIDFA])
//                                {
//                                    
//                                    
//                                    manager.state01 = nil;
//                                    manager.state1081 = nil;
//                                    manager.deviceID = nil;
//                                    manager.returnData = nil;
//                                    manager.expirationTime = nil;
//                                    manager.activationTime = nil;
//                                    //已经有卡密没到期
//                                    
//                                    
//                                    DisPatchGetMainQueueBegin();
//                                   MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
//                                                                     hud.mode = MBProgressHUDModeText;
//                                                                     hud.label.text = [NSString stringWithFormat:@"到期时间:%@",arr[4]];
//                                                                     hud.userInteractionEnabled = NO;
//                                                                     [hud hideAnimated:YES afterDelay:3.5f];
//                                        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                                            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//
//                                                        extraInfo =  [PubgLoad new];
//                                                        [extraInfo initTapGes];
//                                                        [extraInfo tapIconView];
//                                             
//                                            });
//                                            
//                                            NSString * strmutualkey = NULL;
//                                            strmutualkey  = [DES3Utill decrypt:LD_KEY gkey:LD_AAAA];
//                                            NSString * strhost = NULL;
//                                            strhost  = [DES3Utill decrypt:LD_API gkey:LD_AAAA];
//                                            NSString * version = NULL;
//                                            version  = [DES3Utill decrypt:LD_VERSION gkey:LD_AAAA];
//                                            NSString *localv = version;
//                                            NSMutableDictionary *param = [NSMutableDictionary dictionary];
//                                            param[@"api"] =@"v.in";
//                                            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
//                                            [dateFormatter setDateFormat:@"yyyy-MM-dd#HH:mm:ss"];
//                                            NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
//                                            param[@"BSphpSeSsL"] = [dateStr MD5Digest];
//                                            NSDate *date = [NSDate date];
//                                            NSTimeZone * zone = [NSTimeZone systemTimeZone];
//                                            NSInteger interval = [zone secondsFromGMTForDate:date];
//                                            NSDate * nowDate = [date dateByAddingTimeInterval:interval];
//                                            NSString *nowDateStr = [[nowDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
//                                            param[@"date"] = nowDateStr;
//                                          //  param[@"md5"] = [DES3Utill decrypt:LD_MD5 gkey:LD_AAAA];
//                                            param[@"mutualkey"] = strmutualkey;
//                                            //开始检测版本
//                                            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                                                
//                                                [NetTool Post_AppendURL:strhost myparameters:param mysuccess:^(id responseObject) {
//                                                    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//                                                    if (dict) {
//                                                        NSString *version = dict[@"response"][@"data"];
//                                                        BOOL result = [version isEqualToString:localv];
//                                                        if (result) {
//                                                            //版本通过检测获取公告
//                                                            
//                                                            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
//                                                                           {
//                                                                NSMutableDictionary *param = [NSMutableDictionary dictionary];
//                                                                param[@"api"] = @"gg.in";
//                                                                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
//                                                                [dateFormatter setDateFormat:@"yyyy-MM-dd#HH:mm:ss"];
//                                                                NSString *dateStr = [dateFormatter stringFromDate:[NSDate date]];
//                                                                param[@"BSphpSeSsL"] = [dateStr MD5Digest];
//                                                                NSDate *date = [NSDate date];
//                                                                NSTimeZone * zone = [NSTimeZone systemTimeZone];
//                                                                NSInteger interval = [zone secondsFromGMTForDate:date];
//                                                                NSDate * nowDate = [date dateByAddingTimeInterval:interval];
//                                                                NSString *nowDateStr = [[nowDate description] stringByReplacingOccurrencesOfString:@" +0000" withString:@""];
//                                                                param[@"date"] = nowDateStr;
//                                                             //   param[@"md5"] = [DES3Utill decrypt:LD_MD5 gkey:LD_AAAA];
//                                                                param[@"mutualkey"] = strmutualkey;
//                                                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                                                                    
//                                                                    [NetTool Post_AppendURL:strhost myparameters:param mysuccess:^(id responseObject) {
//                                                                        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableContainers error:nil];
//                                                                        if (dict) {
//                                                                            NSString *message = dict[@"response"][@"data"];
//                                                                            if ([message rangeOfString:@"NULL"].location == NSNotFound)
//                                                                            {
//                                                                                SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//                                                                                [alert addTimerToButtonIndex:0 reverse:YES];
//                                                                                alert.horizontalButtons = YES;
//                                                                                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
//                                                                                               {
//                                                                                    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//                                                                                    [alert addTimerToButtonIndex:0 reverse:YES];
//                                                                                    alert.horizontalButtons = YES;
//
//                                                                                }
//                                                                     
//                                                                                               );}
//                                                                            
//                                                                            
//                                                                        }
//                                                                    } myfailure:^(NSError *error) {
//                                                                        SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//                                                                        [alert addTimerToButtonIndex:0 reverse:YES];
//                                                                        [alert showInfo:@"温馨提示" subTitle:(@"破解有几率触发白苹果") closeButtonTitle:@"确定" duration:0.0f];
//                                                                    }];
//                                                                });
//                                                            });
//                                                        }else{
//                                                            
//                                                            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
//                                                                SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//                                                                [alert addTimerToButtonIndex:0 reverse:YES];
//                                                                alert.horizontalButtons = YES;
//                                                                // 拒绝按钮
//                                                                [alert addButton:@"确定" actionBlock:^{
//                                                                    exit(0);
//                                                                }];
//                                                                
////                                                                // 下载按钮
////                                                                [alert addButton:@"前往下载" actionBlock:^{
////                                                                    //
////                                                                    NSString *urlStr = [NSString stringWithFormat:@""];[[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
////                                                                    exit(0);
////                                                                }];
//                                                                [alert showInfo:@"" subTitle:@"当前版本已过期,请及时更新版本！" closeButtonTitle:nil duration:0.0f];
//                                                                
//                                                            });
//                                                        }
//                                                    }
//                                                } myfailure:^(NSError *error)
//                                                 {
//                                                    SCLAlertView *alert = [[SCLAlertView alloc] initWithNewWindow];
//                                                    [alert addTimerToButtonIndex:0 reverse:YES];
//                                                    [alert addButton:@"退出倒计时" actionBlock:^{
//                                                        exit(0);
//                                                    }];
//                                                    [alert showInfo:@"温馨提示" subTitle:(@"网络连接失败！请重启应用！") closeButtonTitle:nil duration:10];
//                                                }];
//                                            });
//                                        });
//
//                                        
////                                    }];
////                                    [alert showInfo:@"验证成功" subTitle:showMsg closeButtonTitle:nil duration:0.0f];
//                                    DisPatchGetMainQueueEnd();
//                                    
//                                    
//                                }
//                            }else{
//                                exit(0);
//                                
//                                
//                            }
//                        }
//                    }
//                    else
//                    {
//                        UserInfoManager *manager =   [UserInfoManager shareUserInfoManager];
//                        manager.state01 = nil;
//                        manager.state1081 = nil;
//                        manager.deviceID = nil;
//                        manager.returnData = nil;
//                        manager.expirationTime = nil;
//                        manager.activationTime = nil;
//                        
//                        //到期返回激活
//                        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
//                                       {
//                            [[VerifyEntry MySharedInstance] processActivate];
//                            
//                        });
//                    }
//                }
//            } myfailure:^(NSError *error)
//             {
//                dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
//                               {
//                    [[VerifyEntry MySharedInstance] processActivate];
//                });
//            }];
//        }
//        else
//        {
//            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^
//                           {
//                [[VerifyEntry MySharedInstance] processActivate];
//                
//            });
//        }
//        
//        
//    });
//}
//
//-(void)initTapGes
//{
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] init];
//    tap.numberOfTapsRequired = 3;//点击次数
//    tap.numberOfTouchesRequired = 3;//手指数
//    [[JHPP currentViewController].view addGestureRecognizer:tap];
//    [tap addTarget:self action:@selector(gzb:)];
//}
//
//-(void)tapIconView
//{
//     if (!_vna) {
//         metalbiew *vc = [[metalbiew alloc] init];
//         _vna = vc;
//     }
//     [metalbiew showChange:false];
// [[UIApplication sharedApplication].windows[0].rootViewController.view addSubview:_vna.view];
//   
//    UIWindow * window = [UIApplication sharedApplication].keyWindow;
//    [window addSubview:_vna.view];
//    
//    JHDragView *view = [[JHPP currentViewController].view viewWithTag:100];
//    if (!view) {
//        view = [[JHDragView alloc] init];
//        view.tag = 100;
//        [[JHPP currentViewController].view addSubview:view];
//        
//        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onConsoleButtonTapped:)];
//        tap.numberOfTapsRequired = 1;
//        [view addGestureRecognizer:tap];
//    }
//    if (!MenDeal) {
//        view.hidden = NO;
//    } else {
//        view.hidden = YES;
//    }
//    MenDeal = !MenDeal;
//}
//-(void)onConsoleButtonTapped:(id)sender
//{
//    [metalbiew showChange:true];
//  [[UIApplication sharedApplication].windows[0].rootViewController.view addSubview:_vna.view];
//}
//-(void)gzb:(id)sender
//{
//   HeeeNoScreenShotView *noScreenShotView = [[HeeeNoScreenShotView alloc] initWithFrame:CGRectMake(0, 0, kWidth, kHeight)];
//     [noScreenShotView addSubview:_vna.view];
//     [noScreenShotView setUserInteractionEnabled:NO];
//    [[UIApplication sharedApplication].windows[0].rootViewController.view addSubview:noScreenShotView];
//
//}
//
//
//
//@end
